package com.divya.ai

import android.content.Context
import android.graphics.*
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Log
import android.view.Surface
import androidx.camera.core.ImageProxy
import java.io.File
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Scanner Live Edit.
 *
 * Camera ke har frame par EDIT usi waqt lagta hai (color grade, letterbox, vignette, title, caption, zoom) aur wo seedha
 * H.264 encoder mein jata hai. Awaaz (mic + halka music) bhi saath-saath AAC mein encode hoti hai.
 * Isliye STOP dabate hi sirf encoder band karna + chhoti si file jodni baaki hoti hai -> video ~1 second ke andar ready.
 *
 * Frames ScanScreen ke ImageAnalysis se aate hain (push), mic Gemini ke mic loop se (micIn).
 * Divya ke tools: scan_video_start / scan_video_caption / scan_video_stop.
 */
object LiveEdit {
    private const val TAG = "DivyaLiveEdit"
    private const val W = 720
    private const val H = 1280
    private const val FPS = 30
    private const val ASR = 16000
    private const val MAX_SEC = 90

    @Volatile var recording = false
        private set
    @Volatile var style = "cinematic"
    @Volatile var title = ""
    @Volatile var caption: String = ""
        set(v) { field = v.take(120); capAtNs = System.nanoTime() }
    @Volatile private var capAtNs = 0L
    @Volatile var lastFile: File? = null
    @Volatile var lastMs = 0L
    @Volatile var error = ""

    val STYLES = listOf("cinematic" to "🎬 Cinematic", "vivid" to "🌈 Vivid", "sad" to "😢 Sad", "bw" to "⚫ B&W", "retro" to "📼 Retro", "hype" to "🔥 Hype")

    private val lock = Any()
    private var ctx: Context? = null
    private var t0Ns = 0L
    private var firstFrameNs = -1L
    private var firstRawUs = -1L

    private var vCodec: MediaCodec? = null
    private var surface: Surface? = null
    private var vMux: MediaMuxer? = null
    private var vTrack = -1
    private var vStarted = false
    private var vFile: File? = null
    private val vInfo = MediaCodec.BufferInfo()

    private var aCodec: MediaCodec? = null
    private var aMux: MediaMuxer? = null
    private var aTrack = -1
    private var aStarted = false
    private var aFile: File? = null
    private val aInfo = MediaCodec.BufferInfo()
    @Volatile private var audioRun = false
    private var audioThread: Thread? = null

    private val micRing = ShortArray(ASR * 2)
    private var micW = 0L
    private var micR = 0L
    private val micLock = Any()

    private val fbs = arrayOfNulls<Bitmap>(3)
    private var fbi = 0
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val mat = Matrix()
    private val filters = HashMap<String, ColorMatrixColorFilter>()
    private val vigPaint = Paint()
    private val fillP = Paint()
    private val srcR = Rect()
    private val serifP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL); color = Color.WHITE }
    private val boldP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD); color = Color.WHITE }
    private val wmP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 255, 255, 255); textSize = 24f; typeface = Typeface.MONOSPACE }
    private var layKey = ""
    private var layCache: StaticLayout? = null
    private var autoStopping = false

    val elapsedSec: Double get() = if (recording) (System.nanoTime() - t0Ns) / 1e9 else 0.0

    // ------------------------------------------------------------------ START
    fun start(c: Context, st: String, ttl: String, cap: String): String = synchronized(lock) {
        if (recording) return "recording pehle se chal rahi hai"
        try {
            ctx = c.applicationContext
            style = if (STYLES.any { it.first == st }) st else "cinematic"
            title = ttl.trim().take(60); caption = cap.trim()
            error = ""; autoStopping = false
            val vf = File(c.cacheDir, "le_v.mp4").also { it.delete() }; vFile = vf
            val af = File(c.cacheDir, "le_a.m4a").also { it.delete() }; aFile = af

            val vfmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, W, H).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, 8_000_000); setInteger(MediaFormat.KEY_FRAME_RATE, FPS); setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val vc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            vc.configure(vfmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            surface = vc.createInputSurface(); vc.start(); vCodec = vc
            vMux = MediaMuxer(vf.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4); vTrack = -1; vStarted = false

            val afmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, ASR, 1).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 64000); setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            val ac = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            ac.configure(afmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); ac.start(); aCodec = ac
            aMux = MediaMuxer(af.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4); aTrack = -1; aStarted = false

            firstFrameNs = -1; firstRawUs = -1
            synchronized(micLock) { micW = 0; micR = 0 }
            t0Ns = System.nanoTime()
            recording = true
            audioRun = true
            audioThread = Thread({ audioLoop() }, "LiveEditAudio").also { it.start() }
            "recording shuru (style: $style)"
        } catch (e: Throwable) {
            Log.e(TAG, "start", e); error = e.message ?: e.javaClass.simpleName
            cleanup()
            "failed: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    // ------------------------------------------------------------------ MIC (Gemini ke mic loop se, 16kHz mono 16-bit LE)
    fun micIn(buf: ByteArray, n: Int) {
        if (!recording) return
        synchronized(micLock) {
            var i = 0
            while (i + 1 < n) {
                micRing[(micW % micRing.size).toInt()] = ((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)).toShort()
                micW++; i += 2
            }
            if (micW - micR > micRing.size) micR = micW - micRing.size
        }
    }

    // ------------------------------------------------------------------ AUDIO THREAD (mic + halka music -> AAC), real-time clock par
    private fun audioLoop() {
        val cd = aCodec ?: return
        var fed = 0L
        val chunk = 800
        try {
            while (audioRun) {
                val want = (System.nanoTime() - t0Ns) * ASR / 1_000_000_000L - fed
                if (want < chunk) { try { Thread.sleep(8) } catch (_: InterruptedException) { break }; drainAudio(false); continue }
                val ii = cd.dequeueInputBuffer(5_000)
                if (ii < 0) { drainAudio(false); continue }
                val buf = cd.getInputBuffer(ii)!!; buf.clear(); buf.order(java.nio.ByteOrder.LITTLE_ENDIAN)
                val music = style == "sad" || style == "cinematic"
                for (k in 0 until chunk) {
                    var s = 0
                    synchronized(micLock) { if (micR < micW) { s = micRing[(micR % micRing.size).toInt()].toInt(); micR++ } }
                    if (music) s += musicSample(fed + k)
                    buf.putShort(s.coerceIn(-32768, 32767).toShort())
                }
                cd.queueInputBuffer(ii, 0, chunk * 2, fed * 1_000_000L / ASR, 0)
                fed += chunk
                drainAudio(false)
            }
            // end of stream
            var ii = -1; var tries = 0
            while (ii < 0 && tries++ < 50) ii = cd.dequeueInputBuffer(20_000)
            if (ii >= 0) cd.queueInputBuffer(ii, 0, 0, fed * 1_000_000L / ASR, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drainAudio(true)
        } catch (e: Throwable) { Log.w(TAG, "audio", e) }
    }

    private fun drainAudio(end: Boolean) {
        val cd = aCodec ?: return
        val dl = System.currentTimeMillis() + 2000
        while (true) {
            val oi = cd.dequeueOutputBuffer(aInfo, if (end) 10_000 else 0)
            if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                aTrack = aMux!!.addTrack(cd.outputFormat); aMux!!.start(); aStarted = true
            } else if (oi >= 0) {
                val ob = cd.getOutputBuffer(oi)!!
                if (aInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) aInfo.size = 0
                if (aInfo.size > 0 && aStarted) { ob.position(aInfo.offset); ob.limit(aInfo.offset + aInfo.size); aMux!!.writeSampleData(aTrack, ob, aInfo) }
                cd.releaseOutputBuffer(oi, false)
                if (aInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
            } else if (!end || System.currentTimeMillis() > dl) return
        }
    }

    /** Halka original ambient music (Am-F-C-G). Copyright wala gaana nahi. */
    private val prog = arrayOf(intArrayOf(57, 60, 64), intArrayOf(53, 57, 60), intArrayOf(48, 52, 55), intArrayOf(55, 59, 62))
    private fun hz(m: Int) = 440.0 * Math.pow(2.0, (m - 69) / 12.0)
    private val padF = Array(4) { c -> DoubleArray(3) { k -> hz(prog[c][k] - 12) } }
    private val pluckF = Array(4) { c -> DoubleArray(3) { k -> hz(prog[c][k] + 12) } }
    private fun musicSample(i: Long): Int {
        val chordLen = ASR * 4L
        val ci = ((i / chordLen) % 4).toInt()
        val pos = (i % chordLen).toDouble() / ASR
        val t = i.toDouble() / ASR
        val e = sin(PI * pos / 4.0)
        var pad = 0.0
        for (k in 0 until 3) pad += sin(2 * PI * padF[ci][k] * t)
        pad = pad / 3.0 * e * 1300.0
        val step = (pos / 0.5).toInt(); val pp = pos - step * 0.5
        val pl = sin(2 * PI * pluckF[ci][step % 3] * t) * Math.exp(-pp * 5.0) * min(1.0, pp * 150.0) * 1500.0
        return ((pad + pl) * min(1.0, t / 1.0)).toInt()
    }

    // ------------------------------------------------------------------ VIDEO: har camera frame par live edit
    fun push(img: ImageProxy) {
        if (!recording) return
        synchronized(lock) {
            if (!recording) return
            val sf = surface ?: return
            try {
                val pl = img.planes[0]; val buf = pl.buffer; val bw = pl.rowStride / 4
                var fb = fbs[fbi]
                if (fb == null || fb.width != bw || fb.height != img.height) { fb?.recycle(); fb = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888); fbs[fbi] = fb }
                fbi = (fbi + 1) % fbs.size
                buf.rewind(); fb.copyPixelsFromBuffer(buf); buf.rewind()
                val now = System.nanoTime()
                if (firstFrameNs < 0) firstFrameNs = now
                val t = (now - t0Ns) / 1e9
                val cv = sf.lockHardwareCanvas()
                try { drawFrame(cv, fb, img.width, img.height, img.imageInfo.rotationDegrees, t) } finally { sf.unlockCanvasAndPost(cv) }
                drainVideo(false)
                if (t > MAX_SEC && !autoStopping) { autoStopping = true; Thread { stop() }.start() }
            } catch (e: Throwable) { Log.w(TAG, "push", e); error = e.message ?: "frame error" }
        }
    }

    private fun drainVideo(end: Boolean) {
        val cd = vCodec ?: return
        val dl = System.currentTimeMillis() + 2000
        while (true) {
            val oi = cd.dequeueOutputBuffer(vInfo, if (end) 10_000 else 0)
            if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                vTrack = vMux!!.addTrack(cd.outputFormat); vMux!!.start(); vStarted = true
            } else if (oi >= 0) {
                val ob = cd.getOutputBuffer(oi)!!
                if (vInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) vInfo.size = 0
                if (vInfo.size > 0 && vStarted) {
                    if (firstRawUs < 0) firstRawUs = vInfo.presentationTimeUs
                    vInfo.presentationTimeUs = (vInfo.presentationTimeUs - firstRawUs) + (max(0L, firstFrameNs - t0Ns)) / 1000
                    ob.position(vInfo.offset); ob.limit(vInfo.offset + vInfo.size); vMux!!.writeSampleData(vTrack, ob, vInfo)
                }
                cd.releaseOutputBuffer(oi, false)
                if (vInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
            } else if (!end || System.currentTimeMillis() > dl) return
        }
    }

    // ------------------------------------------------------------------ EDIT (har frame par)
    private fun cm(sat: Float, contrast: Float, bright: Float, r: Float = 1f, g: Float = 1f, b: Float = 1f): ColorMatrixColorFilter {
        val m = ColorMatrix(); m.setSaturation(sat)
        val o = (1f - contrast) * 127.5f + bright
        m.postConcat(ColorMatrix(floatArrayOf(contrast * r, 0f, 0f, 0f, o, 0f, contrast * g, 0f, 0f, o, 0f, 0f, contrast * b, 0f, o, 0f, 0f, 0f, 1f, 0f)))
        return ColorMatrixColorFilter(m)
    }
    private fun filterFor(st: String): ColorMatrixColorFilter = filters.getOrPut(st) {
        when (st) {
            "vivid" -> cm(1.35f, 1.08f, 6f)
            "sad" -> cm(0.30f, 1.15f, -18f, 0.92f, 0.98f, 1.12f)
            "bw" -> cm(0f, 1.2f, -4f)
            "retro" -> cm(0.7f, 1.05f, 8f, 1.12f, 1.02f, 0.82f)
            "hype" -> cm(1.5f, 1.2f, 0f)
            else -> cm(0.9f, 1.12f, -6f, 1.06f, 1.0f, 0.94f)
        }
    }

    private fun drawFrame(c: Canvas, fb: Bitmap, w: Int, h: Int, rot: Int, t: Double) {
        val st = style
        c.drawColor(Color.BLACK)
        val uw = if (rot == 90 || rot == 270) h else w
        val uh = if (rot == 90 || rot == 270) w else h
        val s = max(W.toFloat() / uw, H.toFloat() / uh)
        var z = 1f + 0.06f * (0.5f - 0.5f * cos(t * 0.35)).toFloat()             // dheema zoom (cinematic feel)
        if (st == "hype") z += 0.05f * max(0f, 1f - ((t % 1.8) / 0.25).toFloat())  // beat jaisa zoom punch
        mat.reset(); mat.postTranslate(-w / 2f, -h / 2f); mat.postRotate(rot.toFloat()); mat.postScale(s * z, s * z); mat.postTranslate(W / 2f, H / 2f)
        paint.colorFilter = filterFor(st)
        srcR.set(0, 0, w, h)
        c.save(); c.concat(mat); c.drawBitmap(fb, srcR, srcR, paint); c.restore()
        paint.colorFilter = null

        // vignette
        vigPaint.shader = RadialGradient(W / 2f, H / 2f, H * 0.68f, 0x00000000, if (st == "sad") 0xAA000000.toInt() else 0x66000000, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), vigPaint); vigPaint.shader = null

        // letterbox (cinematic / sad)
        val bar = if (st == "cinematic") 150f else if (st == "sad") 210f else 0f
        if (bar > 0f) { fillP.color = Color.BLACK; c.drawRect(0f, 0f, W.toFloat(), bar, fillP); c.drawRect(0f, H - bar, W.toFloat(), H.toFloat(), fillP) }

        // retro REC + time
        if (st == "retro") {
            val sec = t.toInt()
            val rp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 34f; typeface = Typeface.MONOSPACE }
            if ((t * 2).toInt() % 2 == 0) { fillP.color = Color.RED; c.drawCircle(60f, 78f, 12f, fillP) }
            c.drawText("REC %02d:%02d".format(sec / 60, sec % 60), 84f, 90f, rp)
        }

        val serif = st == "sad" || st == "cinematic"
        // title (shuru ke 3 sec)
        val ttl = title
        if (ttl.isNotBlank() && t < 3.0) {
            val a = (min(1.0, t / 0.4) * min(1.0, (3.0 - t) / 0.5)).coerceIn(0.0, 1.0)
            val tp = if (serif) serifP else boldP
            tp.textSize = 68f; tp.alpha = (255 * a).toInt(); tp.setShadowLayer(8f, 0f, 3f, Color.argb((200 * a).toInt(), 0, 0, 0))
            val lay = layout(ttl, tp, W - 120)
            c.save(); c.translate(60f, H * 0.38f - lay.height / 2f); lay.draw(c); c.restore()
            tp.alpha = 255; tp.clearShadowLayer()
        }
        // caption
        val cap = caption
        if (cap.isNotBlank()) {
            val a = min(1.0, (System.nanoTime() - capAtNs) / 1e9 / 0.35).coerceIn(0.0, 1.0)
            val tp = if (serif) serifP else boldP
            tp.textSize = 48f; tp.alpha = (255 * a).toInt(); tp.setShadowLayer(7f, 0f, 3f, Color.argb((220 * a).toInt(), 0, 0, 0))
            val lay = layout(cap, tp, W - 100)
            c.save(); c.translate(50f, H - bar - 90f - lay.height); lay.draw(c); c.restore()
            tp.alpha = 255; tp.clearShadowLayer()
        }
        c.drawText("DIVYA AI", W - 160f, H - bar - 24f, wmP)
    }

    private fun layout(text: String, tp: TextPaint, width: Int): StaticLayout {
        val key = text + "|" + tp.textSize + "|" + (tp.typeface === serifP.typeface) + "|" + width
        if (key != layKey || layCache == null) {
            layCache = StaticLayout.Builder.obtain(text, 0, text.length, tp, width).setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0f, 1.1f).build()
            layKey = key
        }
        // paint (alpha/shadow) har baar naya lagta hai, isliye layout ka paint hi use hota hai (same object)
        return layCache!!
    }

    // ------------------------------------------------------------------ STOP: ~1 second mein video ready
    fun stop(): String {
        val ts = System.nanoTime()
        val c: Context
        synchronized(lock) {
            if (!recording) return "recording chal hi nahi rahi"
            recording = false
            c = ctx ?: return "failed: context nahi"
            try { vCodec?.signalEndOfInputStream(); drainVideo(true) } catch (e: Throwable) { Log.w(TAG, "v end", e) }
        }
        audioRun = false
        try { audioThread?.join(3000) } catch (_: InterruptedException) {}
        val hadVideo = vStarted
        val hadAudio = aStarted
        val vf = vFile; val af = aFile
        closeAll()
        if (!hadVideo || vf == null || !vf.exists() || vf.length() < 1000) { error = "koi frame nahi aaya"; return "failed: camera se koi frame nahi aaya (scanner khula hona chahiye)" }
        val name = "divya_live_" + java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date()) + ".mp4"
        val out = File(VideoGen.dir(c), name)
        try {
            if (hadAudio && af != null && af.exists() && af.length() > 1000) VideoGen.mergeFiles(vf, af, out) else vf.copyTo(out, true)
        } catch (e: Throwable) {
            Log.w(TAG, "merge", e)
            try { vf.copyTo(out, true) } catch (e2: Throwable) { error = e2.message ?: "save fail"; return "failed: ${e2.message}" }
        }
        vf.delete(); af?.delete()
        lastFile = out
        lastMs = (System.nanoTime() - ts) / 1_000_000L
        val ttl = title; val cap = caption
        Thread {
            try { File(out.path + ".txt").writeText((ttl.ifBlank { "Live Edit" }) + "\n" + cap) } catch (_: Exception) {}
            try { VideoGen.saveToGallery(c, out) } catch (e: Exception) { Log.w(TAG, "gallery", e) }
        }.start()
        return "done: video ready (${lastMs} ms mein). Movies/DivyaVideos mein save hai aur Video screen mein dikh rahi hai."
    }

    private fun closeAll() {
        try { vCodec?.stop() } catch (_: Throwable) {}
        try { vCodec?.release() } catch (_: Throwable) {}
        try { if (vStarted) vMux?.stop() } catch (_: Throwable) {}
        try { vMux?.release() } catch (_: Throwable) {}
        try { aCodec?.stop() } catch (_: Throwable) {}
        try { aCodec?.release() } catch (_: Throwable) {}
        try { if (aStarted) aMux?.stop() } catch (_: Throwable) {}
        try { aMux?.release() } catch (_: Throwable) {}
        try { surface?.release() } catch (_: Throwable) {}
        vCodec = null; aCodec = null; vMux = null; aMux = null; surface = null
        vStarted = false; aStarted = false
        for (i in fbs.indices) { try { fbs[i]?.recycle() } catch (_: Throwable) {}; fbs[i] = null }
    }

    private fun cleanup() {
        recording = false; audioRun = false
        closeAll()
        vFile?.delete(); aFile?.delete()
    }
}
