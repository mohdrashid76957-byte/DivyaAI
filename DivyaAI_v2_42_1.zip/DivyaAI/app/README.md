
## v2.40.0 - Video "bekar/neon" fix + About fix
- **Asli bug (video):** voice se "facts / funny / viral reel" bolne par Divya ko prompt mein bola gaya tha `visuals=instant` -> AI image ki jagah sirf neon ring + gradient background (video jaisi bekar). Ab saari reels (facts, funny, attitude, motivation, story) `visuals=ai` se asli AI images ke saath banti hain. `GeminiLive.kt` prompt + tool schema + call site badle (voice se ab "instant/neon" jaa hi nahi sakta).
- **Chupke se neon band:** AI Real mode mein agar koi bhi image na bane to pehle neon video ban jati thi. Ab saaf error aata hai (`imgErr` ke saath: internet / Gemini key / Settings).
- **Preview:** AI mode mein preview tab shuru hoti hai jab pehli asli image aa jaye (max 45 sec), neon preview nahi.
- **Quality:** images 720x1280 (pehle 576x1024 upscale), natural photo-style prompt (over-processed "8k/ARRI/not CGI" hata diya), video bitrate 9 Mbps, halka vignette. Script prompt ab style (facts/funny/attitude) samajhta hai aur har line ke hisaab se real-looking scene banata hai + strong hook.
- **About fix:** "Latest Update" list ab `Changelog.latest` (NeonHome.kt) se aati hai - purani v2.22 list hata di. Stale fallback version `BuildConfigVersion.NAME` (2.22.22) bhi 2.40.0 kiya. Naya version banao to `build.gradle.kts` + `Changelog.latest` (+ `BuildConfigVersion.NAME`) badlo.
- versionCode 66 / versionName 2.40.0 (purane APK ke upar install ho jayegi).
- Limit (sach): ye abhi bhi **AI stills + camera move** hai, har frame ka asli AI-video nahi. Asli chalte-phirte clips ke liye paid video model (jaise Veo) chahiye - alag step.
- **Compile aur phone par test nahi hua** (yahan Android SDK/internet nahi tha).
