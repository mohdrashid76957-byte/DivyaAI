package com.divya.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

fun camOk(c: Context) = c.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

/**
 * Scanner / "Dekho" screen: camera preview + live frames (about 1 per second) Divya ko bhejta hai.
 * Divya apni awaaz mein bata deti hai ki kya dikh raha hai (cheezein, text, documents, jagah, QR ke aas-paas ka text).
 */
@Composable
fun ScanScreen(th: UiTheme, live: GeminiLive, running: Boolean, status: String, startSession: () -> Unit, ask: (String) -> Unit, close: () -> Unit) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(camOk(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }
    // Screen khulte hi Divya ka session shuru karo (agar chal nahi raha)
    LaunchedEffect(granted) { if (granted && !live.running) startSession() }

    Box(Modifier.fillMaxSize()) {
        if (granted) {
            CameraPreview(live)
        } else {
            Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Text("Divya ko dekhne ke liye Camera permission chahiye", color = th.text, textAlign = TextAlign.Center, fontSize = 16.sp)
                Spacer(Modifier.height(12.dp))
                Btn(th, "Camera Allow karo") { launcher.launch(Manifest.permission.CAMERA) }
            }
        }
        // Upar: status
        Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(16.dp))
            .background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.QrCodeScanner, "Scanner", tint = th.accent)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text("Divya Scanner", color = Color.White, fontWeight = FontWeight.Bold)
                Text(if (running) "👁️ Divya dekh rahi hai • $status" else "Connect ho raha hai… ($status)", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
            }
            IconButton(close) { Icon(Icons.Filled.Close, "Band karo", tint = Color.White) }
        }
        // Neeche: quick sawal
        if (granted) Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val chips = listOf(
                "Ye kya hai?" to "Camera mein jo dikh raha hai use dekho aur batao ye kya hai.",
                "Text padho" to "Camera mein jo text ya document dikh raha hai use poora padhkar sunao.",
                "QR / Code" to "Camera mein jo QR code ya barcode dikh raha hai, uske aas-paas ka text padho aur batao kya likha hai.",
                "Samjhao" to "Jo dikh raha hai use asaan Hinglish mein samjhao."
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                chips.take(2).forEach { (l, q) -> ScanChip(th, l, Modifier.weight(1f)) { ask(q) } }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                chips.drop(2).forEach { (l, q) -> ScanChip(th, l, Modifier.weight(1f)) { ask(q) } }
            }
            Text("Bolo bhi sakte ho: “ye kya hai?”, “ye padh do”", color = Color.White, fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(alpha = 0.45f)).padding(6.dp))
        }
    }
}

@Composable
private fun ScanChip(th: UiTheme, label: String, modifier: Modifier, onClick: () -> Unit) {
    Button(onClick, modifier.border(1.dp, th.accent, RoundedCornerShape(22.dp)), shape = RoundedCornerShape(22.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Black.copy(alpha = 0.6f))) { Text(label, color = Color.White, fontSize = 13.sp) }
}

@Composable
private fun CameraPreview(live: GeminiLive) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val exec = remember { Executors.newSingleThreadExecutor() }
    val providerRef = remember { arrayOfNulls<ProcessCameraProvider>(1) }
    DisposableEffect(Unit) { onDispose { try { providerRef[0]?.unbindAll() } catch (_: Exception) {}; exec.shutdown() } }
    AndroidView(Modifier.fillMaxSize(), factory = { c ->
        val pv = PreviewView(c).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        val fut = ProcessCameraProvider.getInstance(c)
        fut.addListener({
            try {
                val provider = fut.get(); providerRef[0] = provider
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                var last = 0L
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(exec) { img ->
                    try {
                        val now = System.currentTimeMillis()
                        if (live.running && now - last >= 1000) {
                            last = now
                            var bmp: Bitmap = img.toBitmap()
                            val rot = img.imageInfo.rotationDegrees
                            if (rot != 0) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
                            val maxSide = 768f
                            val sc = maxSide / maxOf(bmp.width, bmp.height)
                            if (sc < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true)
                            val out = ByteArrayOutputStream()
                            bmp.compress(Bitmap.CompressFormat.JPEG, 70, out)
                            live.sendFrame(out.toByteArray())
                        }
                    } catch (_: Exception) {
                    } finally { img.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(c))
        pv
    })
}
