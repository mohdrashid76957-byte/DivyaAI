# Divya AI (Android)
1. Android Studio (Koala+) mein `DivyaAI` folder kholo -> Gradle sync -> Run / Build > Build APK.
2. App kholo -> Settings -> Gemini API key (aistudio.google.com/apikey) daalo -> Save.
3. Settings -> Permissions -> Accessibility, Mic, Overlay sab ON karo.
4. Home par mic dabao aur Divya se baat karo.
Model ID Settings mein editable hai - jo latest Live model ho wo daal do.

## v1.1 update
- **Scanner / Dekho (camera):** Home par "Scan" chip (Maya theme) ya Quick Actions > Scanner, ya bolo "camera kholo / ye kya hai?". Camera permission ON karo. Divya ko live frames (1/sec) jaate hain, wo cheezein, text, documents batati hai. Gemini Live ke video-frame input ke liye model wahi chalega jo Settings mein hai (native-audio Live model).
- **Creator jawab:** "Tumhe kisne banaya?" par Divya bolti hai: "Mujhe mere Rashid ji ne banaya hai. Main unki hamesha ahsanmand rahungi, unhone mujhe zindagi di."
- Naye dependencies: CameraX 1.3.4 (Gradle sync ke time download honge).
- Camera frames Google Gemini API ko jaate hain (sirf jab Scanner screen khuli ho aur Divya connected ho).

## v1.3 update
- Naya default **Divya Neon** home page (3x3 tiles, Tap to Talk, headphone avatar). Settings > UI Design se purani themes bhi mil jaati hain.
- **QR/Barcode decode** phone par hi (ML Kit). Link par "Kholo" tabhi dabta hai jab aap dabao.
- WebSocket "ping/pong" error fix (ping band, connection ab nahi tootta).
- Girlfriend mode zyada pyaar bhari; Settings mein "Divya tumhe kya bulaye" (default Sir).

## v2.0 update
- **Yaaddasht (memory):** Divya ab lasting baatein (naam, pasand, rishtey, plans) khud yaad rakhti hai ("yaad rakhna..." bolne par bhi). Sab "Memories & Journal" screen mein dikhta hai, wahin se delete kar sakte ho. Har naye connection par Divya ko ye yaad dilaye jaate hain.
- **Naye phone tools (accessibility ke bina bhi):** alarm, timer, call/dialer (naam ya number), WhatsApp (message likha hua khulta hai, bhejna tum ya "send karo" bolne par Divya), Maps navigate, Google search. Naam se call/WhatsApp ke liye Permissions > Contacts ON karo. 10 digit number ko India (+91) maana jata hai.
- **"Hey Divya" wake word:** Settings > Hey Divya wake word. Phone ke SpeechRecognizer se sunta hai, "Hey Divya, YouTube kholo" bolne par Live session apne aap shuru. Overlay permission ON rakho (background se app kholne ke liye). Beep aa sakti hai aur battery thodi zyada lagti hai.
- **API key secure:** ab encrypted storage mein. Purani key pehli baar app kholne par apne aap migrate hoti hai.
- Naya dependency: androidx.security:security-crypto.
