package com.divya.ai

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Gemini API key encrypted storage mein. Purani plain-text key pehli baar padhne par apne aap migrate ho jaati hai. */
object Secrets {
    private fun enc(c: Context) = EncryptedSharedPreferences.create(
        c, "divya_secure",
        MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private fun plain(c: Context) = c.getSharedPreferences("divya", 0)

    fun apiKey(c: Context): String = try {
        val e = enc(c)
        var k = e.getString("key", "") ?: ""
        if (k.isBlank()) {
            val old = plain(c).getString("key", "") ?: ""
            if (old.isNotBlank()) {
                e.edit().putString("key", old).apply()
                plain(c).edit().remove("key").apply()
                k = old
            }
        }
        k
    } catch (ex: Exception) {
        plain(c).getString("key", "") ?: ""   // fallback agar keystore dikkat kare
    }

    fun setApiKey(c: Context, v: String) {
        try {
            enc(c).edit().putString("key", v).apply()
            plain(c).edit().remove("key").apply()
        } catch (ex: Exception) {
            plain(c).edit().putString("key", v).apply()
        }
    }
}
