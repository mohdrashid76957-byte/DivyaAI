package com.divya.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * "Hey Divya" sunne wali foreground service. Naam sunte hi MainActivity khulti hai aur Gemini Live shuru hota hai.
 * Jab Live chal raha ho (mic uska), ye khud ruk jaati hai (setPaused).
 */
class WakeService : Service() {
    companion object {
        @Volatile private var instance: WakeService? = null
        fun setPaused(p: Boolean) { instance?.let { s -> s.main.post { s.paused = p; if (p) s.stopListening() else s.listen() } } }
    }

    private val main = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var paused = false
    private var alive = false
    private val wake = Regex("(divya|दिव्या|diwya|divyaa)", RegexOption.IGNORE_CASE)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        instance = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("wake", "Hey Divya", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "wake").setContentTitle("Divya sun rahi hai")
            .setContentText("\"Hey Divya\" bolo").setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).build()
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(7, n)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        if (!alive) { alive = true; listen() }
        return START_STICKY
    }

    private fun listen() {
        if (!alive || paused) return
        stopListening()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                val m = wake.find(t)
                if (m != null) trigger(t.substring(m.range.last + 1).trim(' ', ',', '.'))
                else again()
            }
            override fun onError(error: Int) { again() }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"))
    }

    private fun again() { main.postDelayed({ listen() }, 600) }

    private fun stopListening() { try { sr?.destroy() } catch (_: Exception) {}; sr = null }

    private fun trigger(cmd: String) {
        stopListening()
        paused = true   // MainActivity Live shuru karegi; Live band hote hi setPaused(false) aayega
        try {
            startActivity(Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                .putExtra("autostart", true).putExtra("cmd", cmd))
        } catch (e: Exception) { paused = false; again() }
        // safety: 20 sec mein Live shuru nahi hua to dobara sunna shuru
        main.postDelayed({ if (paused && !MainActivityState.liveRunning) { paused = false; listen() } }, 20000)
    }

    override fun onDestroy() {
        alive = false; instance = null
        stopListening(); main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}

/** Service ko pata chale ki Live chal raha hai ya nahi. */
object MainActivityState { @Volatile var liveRunning = false }
