package com.divya.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import org.json.JSONObject

/** Intent-based phone tools: accessibility ke bina bhi kaam karte hain (alarm, timer, call, WhatsApp, maps, search). */
object PhoneTools {
    private fun start(ctx: Context, i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        (DivyaService.instance ?: ctx).startActivity(i)   // service context se background mein bhi khulta hai
        true
    } catch (e: Exception) { false }

    private fun hasContacts(ctx: Context) =
        ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun findNumber(ctx: Context, name: String): String? {
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return null
    }

    /** Number ya contact naam se number nikalo. 10 digit ka number ho to India (+91) maana jata hai. */
    private fun resolve(ctx: Context, who: String): Pair<String?, String?> {   // (number, error)
        val digits = who.filter { it.isDigit() }
        if (digits.length >= 7) return (if (digits.length == 10) "91$digits" else digits) to null
        if (!hasContacts(ctx)) return null to "failed: Contacts permission OFF (Permissions screen se ON karo)"
        val n = findNumber(ctx, who) ?: return null to "failed: '$who' contacts mein nahi mila"
        val d = n.filter { it.isDigit() }
        return (if (d.length == 10) "91$d" else d) to null
    }

    fun run(ctx: Context, name: String, a: JSONObject): String = try {
        when (name) {
            "set_alarm" -> {
                val h = a.optInt("hour", -1); val m = a.optInt("minute", 0)
                if (h !in 0..23 || m !in 0..59) "failed: galat time"
                else if (start(ctx, Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Divya"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true))) "done: alarm set for %02d:%02d".format(h, m)
                else "failed: alarm app nahi khula"
            }
            "set_timer" -> {
                val s = a.optInt("seconds", 0)
                if (s <= 0) "failed: galat time"
                else if (start(ctx, Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, s)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Divya"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true))) "done: timer $s sec"
                else "failed: timer nahi laga"
            }
            "dial" -> {
                val (num, err) = resolve(ctx, a.optString("who"))
                if (num == null) err!! else if (start(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:+$num")))) "done: dialer khul gaya (call user khud dabayega)" else "failed: dialer nahi khula"
            }
            "whatsapp" -> {
                val (num, err) = resolve(ctx, a.optString("who"))
                if (num == null) err!! else {
                    val url = "https://api.whatsapp.com/send?phone=$num&text=" + Uri.encode(a.optString("text"))
                    if (start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))) "done: WhatsApp chat khul gayi, message likha hua hai, bheja nahi gaya" else "failed: WhatsApp nahi khula"
                }
            }
            "navigate" ->
                if (start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.optString("place")))))) "done: maps khul gaya" else "failed: maps nahi khula"
            "web_search" ->
                if (start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))))) "done: search khul gaya" else "failed: browser nahi khula"
            "remember" -> { Memory.add(ctx, a.optString("fact")); "saved" }
            else -> "unknown tool"
        }
    } catch (e: Exception) { "failed: ${e.message}" }

    val names = setOf("set_alarm", "set_timer", "dial", "whatsapp", "navigate", "web_search", "remember")
}
