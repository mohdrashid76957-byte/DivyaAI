package com.divya.ai

import android.content.Context

/** Divya ki yaaddasht. Journal screen wali "notes" list hi use hoti hai, to sab ek jagah dikhta aur delete hota hai. */
object Memory {
    private const val SEP = "\u0001"
    private fun prefs(c: Context) = c.getSharedPreferences("divya", 0)

    fun all(c: Context): List<String> =
        (prefs(c).getString("notes", "") ?: "").split(SEP).filter { it.isNotBlank() }

    fun add(c: Context, fact: String) {
        val t = fact.trim().take(300)
        if (t.isEmpty()) return
        val list = all(c)
        if (list.any { it.substringAfter('\n').equals(t, ignoreCase = true) }) return
        val d = java.text.SimpleDateFormat("d MMM, HH:mm", java.util.Locale.ENGLISH).format(java.util.Date())
        prefs(c).edit().putString("notes", (listOf("🧠 $d\n$t") + list).take(200).joinToString(SEP)).apply()
    }

    /** Prompt ke liye: sabse naye `n` notes, ek line mein. */
    fun forPrompt(c: Context, n: Int = 30): String =
        all(c).take(n).joinToString(" | ") { it.replace("\n", ": ") }
}
