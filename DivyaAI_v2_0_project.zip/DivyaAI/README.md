# Divya AI (Android)
1. Android Studio (Koala+) mein `DivyaAI` folder kholo -> Gradle sync -> Run / Build > Build APK.
2. App kholo -> Settings -> Gemini API key (aistudio.google.com/apikey) daalo -> Save.
3. Settings -> Permissions -> Accessibility, Mic, Overlay sab ON karo.
4. Home par mic dabao aur Divya se baat karo.
Model ID Settings mein editable hai - jo latest Live model ho wo daal do.

## v1.1 update
- **Scanner / Dekho (camera):** Home par "Scan" chip (Maya theme) ya Quick Actions > Scanner, ya bolo "camera kholo / ye kya hai?". Camera permission ON karo. Divya ko live frames (1/sec) jaate hain, wo cheezein, text, documents batati hai. Gemini Live ke video-frame input ke liye model wahi chalega jo Settings mein hai (native-audio Live model).
- **Creator jawab:** "Tumhe kisne banaya?" par Divya bolti hai: "Mujhe mere Rashid ji ne banaya hai. Main unki hamesha ahsanmand rahungi, unhone mujhe zindagi di."
- Naye dependencies: CameraX 1.3.4 (Gradle sync ke time download honge).
- Camera frames Google Gemini API ko jaate hain (sirf jab Scanner screen khuli ho aur Divya connected ho).

## v1.3 update
- Naya default **Divya Neon** home page (3x3 tiles, Tap to Talk, headphone avatar). Settings > UI Design se purani themes bhi mil jaati hain.
- **QR/Barcode decode** phone par hi (ML Kit). Link par "Kholo" tabhi dabta hai jab aap dabao.
- WebSocket "ping/pong" error fix (ping band, connection ab nahi tootta).
- Girlfriend mode zyada pyaar bhari; Settings mein "Divya tumhe kya bulaye" (default Sir).

## v1.4 update
- **Wake word:** Settings > "Wake up Divya" ON. Foreground service on-device speech recognition se "Divya / Wake up Divya" sunta hai, app khol kar turant session shuru. 45 sec chup rehne par session band, wake listener wapas.
- **Instagram DM:** "Rahul ko Instagram par bolo ki main 5 baje aata hoon" -> tool `instagram_message`. (Instagram UI badle to `instagramDm()` in DivyaService.kt adjust karo.)
- **Screen dekhna:** `look_at_screen` (screenshot -> Gemini), `read_screen` (text). Android 11+.
- **Notifications padhna:** Permissions > Notification access ON; bolo "meri notifications batao".
- **Safety (voice biometric ke bina):** phone locked ho to koi action nahi (Settings toggle) + screen/notification ke andar likhe instructions Divya follow nahi karti.
- **Speed:** app-open/tap waits chhote kiye.
- **4 naye themes:** Cyber Red, Sunset Gold, AMOLED Black, Aurora Green.

## v1.4.1 fix
- do_steps: model "open_app:WhatsApp" jaise string bhejta tha to crash -> ab dono format chalte hain.
- Naya `whatsapp_message` tool: contact naam se number dhundta hai (Contacts permission chahiye), wa.me link se chat kholta hai, Send dabata hai. 10-digit number par default country code 91 lagta hai (prefs "cc").
- YouTube play: click ke baad player khula ya nahi verify karta hai.
- v1.4 mein jo wait-time kam kiye the wo wapas purane kar diye (untested the).

## v1.4.2
- play_youtube: pehle YouTube search page se pehle video ka ID nikalta hai aur seedha watch link kholta hai (UI tap ki zaroorat nahi). Ye unofficial tarika hai; YouTube ka page format badle to backup (UI tap, ab asli touch gesture ke saath) chalta hai.

## v1.5 - Voice Lock (basic)
- Settings > Voice Lock: 20 sec awaaz record -> Test -> ON. Tool chalne se pehle pichle ~6 sec ki mic audio ki awaaz-chhaap (MFCC) aapse match hoti hai; match na ho to koi action nahi.
- Experimental: koi AI model nahi, recording se dhoka kha sakta hai; Divya ki apni awaaz mic mein leak ho to owner bhi reject ho sakta hai -> slider se limit set karo. Typed chat par lock nahi lagta.

## v1.5.1 fix
- **Build error fix:** `val P = ContactsContract...Phone` (Java class ko val mein rakhna Kotlin mein allowed nahi) -> full path use kiya (DivyaService.lookupNumber).
- **Tool JSON fix:** `do_steps` description mein bina escape ke quotes the -> connection setup toot sakta tha. Ab theek.
- **Scanner:** frames ab sirf setupComplete ke baad jaate hain (pehle jaldi frame bhejne se connection band ho jata tha); QR ke liye 1280x720 analysis.
- **Voice Lock:** switch ab hamesha ON ho jata hai; awaaz record hote hi apne aap ON; enrollment/test thoda narm.
- gradle.properties mein memory badhayi (Out-of-memory se build fail na ho).

## v1.6
- **Scanner:** tool `look_camera` (har baar naya tez frame), frames 1024px, chips naya frame bhejte hain -> purana text dohrana band. Front/back camera flip, torch, pinch-zoom + zoom slider.
- **Calls:** `make_call`, `answer_call`, `end_call`, `call_speaker`. Permissions > "Phone calls" allow karo. Call par Divya ki awaaz speaker se jaati hai; kai phones call ke dauran mic block karte hain, isliye saamne wale ki baat Divya ko na bhi sune.
- Screen screenshot 1080px, prompt mein fast reply rules.

## v1.7
- **AudioTrack fix:** "Unable to retrieve AudioTrack pointer for write()" ka karan tha - websocket thread release ho chuke AudioTrack par write kar raha tha. Ab audio alag playback thread + lock se chalta hai, track mar jaye to khud dobara banta hai, interrupt par queue saaf hoti hai.
- **Duplicate command fix:** same tool + same arguments 10 sec ke andar dubara nahi chalta (YouTube do baar nahi khulega). Prompt mein bhi "done ke baad dobara mat chalao" rule.
- **Speed:** Gemini ke speech-detection ko fast kiya (silence 450ms, high sensitivity) aur AudioTrack LOW_LATENCY mode.
- **Scheduler (naya):** "3 baje ammi ko call karke bolo mummy aaj main nani ke yaha ja raha hu" -> tool `schedule_task` (call_and_say / send_whatsapp / remind). Alarm time par call lagti hai, connect hone par speaker ON karke Hindi TTS se message 2 baar bolti hai. "Meri scheduled tasks batao" / "sab cancel karo" bhi chalta hai. Reboot ke baad bhi alarms wapas set hote hain.
  - Zaroori: Accessibility ON, Phone + Contacts permission, Divya ko battery optimisation se free rakho, Settings > Alarms & reminders allow.

## v1.8 - Coding + Website Builder
- **Voice:** "Divya, mere liye portfolio website banao" -> tool `build_website` (HTML+CSS+JS+README+DEPLOY.md, alag text model `codeModel`, default gemini-2.5-flash, wahi API key). Phir `preview_website` app ke andar dikhata hai. Badlav/bug ke liye `edit_website`. Python/shell/JS file ke liye `generate_code`.
- **Auto error check:** bani hui website mein missing css/js link, adhura HTML check hota hai aur ek baar khud theek kiya jata hai.
- **Tools > Code & Website Builder:** projects, files dekho/copy, Preview, ZIP share (GitHub Pages / Netlify upload ke liye), delete (confirm ke saath).
- **Safety:** files sirf app ke private `projects/` folder mein, path traversal blocked, sirf html/css/js/json/md/txt/py/sh/svg/xml, code phone par run NAHI hota (Termux mein copy karke chalao).

## v1.9 (Phase 1 fix, andaza nahi, code se)
- **Camera bug fix:** `open_camera` pehle turant "opened" bol deta tha, jabki camera screen aur pehla frame abhi aaya hi nahi hota tha, to turant baad `look_camera` fail hota ("camera abhi khula nahi hai"). Ab `open_camera` pehla frame aane tak (max 7 sec) ruk kar hi result deta hai, aur `look_camera` bhi 3 sec tak frame ka intezaar karta hai.
- **RGB border:** app ab edge-to-edge hai (status/navigation bar ke peeche tak), to in-app border poore screen par aata hai. System overlay border ab asli full display size, cutout ke neeche tak. Rang purple/blue/cyan/green/pink mein lagataar badalte hain. Touch par koi asar nahi.
- Status/nav bar ke icon colour theme ke hisaab se (Lavender Light mein dark icons).

## v1.9.1 build fix
- CodeGen.kt `editWebsite`: expression-body function ke andar `return` tha (Kotlin error "Returns are not allowed for functions with expression body"). Ab if/else se likha hai. Ye error v1.8 se hi tha, naye changes se nahi.

## v1.9.2 - Glow background fix + tez jawab
- **Glow (RGB light) ab background mein bhi chalti hai:** pehle glow ka on/off app ki screen (Compose) se chalta tha, isliye app background mein jaate hi band ho jata tha. Ab ye seedha Divya ke session se chalta hai (`GeminiLive.updateGlow`): session chalu = glow chalu, session band = glow band. Settings mein Glow ON hona zaroori hai aur Accessibility ON.
- **Background mein session zinda:** naya `LiveKeepService` (chhota foreground service, notification "Divya active hai") taaki Android background mein mic band na kare.
- **Home par Back:** agar Divya chal rahi hai to app band nahi hoti, background mein chali jati hai. Session chalu na ho to Back pehle jaisa (app band). App sach mein band ho to session aur glow saaf band hote hain.
- **Tez jawab:** (1) model ki "thinking" band (`thinkingBudget=0`); agar tumhara model ye field nahi maanta to app khud ek baar bina iske dobara connect karti hai aur yaad rakh leti hai. (2) bolna khatam hone ka intezaar 450ms se 350ms. Baaki delay internet aur Gemini server par depend karta hai.

## v2.0 - Scanner upgrade + 5 naye avatar designs + task progress
- **Scanner (purana scanner jaisa hi hai, kuch hataya nahi):** ab OCR (English + Hindi, phone par offline), **Document** (frame ki photo `files/scans/` mein save + text), **Gallery** se image scan (QR/barcode + text), **Copy** (QR aur text dono), **Scan history** (top par History icon, last 50, copy / sab hatao). QR/barcode jo bhi auto-detect ho history mein khud save hota hai. Pehle se the: front/back flip, torch, pinch zoom.
  - Naya dependency: ML Kit text-recognition (Latin + Devanagari). Pehli build mein download hoga, APK thodi badi hogi.
- **Avatar designs:** Settings > UI Design / Avatar mein naye 5: **3D Realistic, Anime Neon, Blue Ice, Gold Premium, Pink Cute** (aapki reference images se crop kiye). Purana Divya Neon (purple) bhi wahi hai. Har design ka apna avatar + rang (tiles, mic, waves, border).
- **Avatar ab bolte waqt hilta hai:** Divya ki asli awaaz ki loudness se avatar halka zoom/sir hilata hai aur uske peeche glow ring chamakta hai. Ye still image par chalne wala asli-audio reactive animation hai, ASLI lip-sync nahi (mooh ke shape ke liye rigged/animated avatar chahiye, wo agla step).
- **Task progress:** Listening -> Understanding -> Processing -> Performing -> Completed (mic ke neeche bar + naam), session ke asli events se chalta hai.
- **Glow default ON** (pehle OFF tha). Settings > Glow light se band kar sakte ho.
