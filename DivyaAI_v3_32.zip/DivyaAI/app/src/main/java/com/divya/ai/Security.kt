package com.divya.ai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

/** v3.32 Biometric Lock: app kholte hi fingerprint / face / screen-lock maangta hai (Home par "Face Lock" tile se ON/OFF). */
object BioLock {
    fun enabled(c: Context) = c.getSharedPreferences("divya", 0).getBoolean("bioLock", false)
    fun set(c: Context, v: Boolean) { c.getSharedPreferences("divya", 0).edit().putBoolean("bioLock", v).apply() }

    /** Phone mein biometric nahi/hardware nahi ho to lock skip (taaki aap bahar na ho jao). Cancel karne par app band. */
    fun prompt(a: Activity, onOk: () -> Unit, onDeny: () -> Unit) {
        if (Build.VERSION.SDK_INT < 28) { onOk(); return }
        try {
            val ex = a.mainExecutor
            val bp = android.hardware.biometrics.BiometricPrompt.Builder(a)
                .setTitle("Divya AI unlock")
                .setSubtitle("Fingerprint / Face se pehchaano")
                .setNegativeButton("Band karo", ex, android.content.DialogInterface.OnClickListener { _, _ -> onDeny() })
                .build()
            bp.authenticate(android.os.CancellationSignal(), ex, object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: android.hardware.biometrics.BiometricPrompt.AuthenticationResult?) { onOk() }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                    // 1 = hw unavailable, 11 = koi biometric enrolled nahi, 12 = hardware nahi, 14 = koi lock set nahi -> skip lock
                    if (errorCode == 1 || errorCode == 11 || errorCode == 12 || errorCode == 14) onOk() else onDeny()
                }
            })
        } catch (e: Exception) { onOk() }
    }
}

/** Emergency SOS: location ke saath SMS (aapke saved number par) + call. Sab user ke tap se (SMS app/dialer khulta hai). */
object SosBus {
    var show by mutableStateOf(false)
    fun open() { Handler(Looper.getMainLooper()).post { show = true } }
}

object Sos {
    fun number(c: Context): String = c.getSharedPreferences("divya", 0).getString("sosNumber", "") ?: ""
    fun save(c: Context, n: String) { c.getSharedPreferences("divya", 0).edit().putString("sosNumber", n.trim()).apply() }
    fun message(c: Context): String {
        val loc = try { PhoneTools.currentLocation(c) } catch (e: Exception) { null }
        val where = if (loc != null) "https://maps.google.com/?q=${loc.latitude},${loc.longitude}" else "(location nahi mili)"
        return "EMERGENCY! Mujhe madad chahiye. Meri location: $where"
    }
    fun sms(c: Context) {
        val n = number(c)
        if (n.isBlank()) { Toast.makeText(c, "Pehle emergency number save karo", Toast.LENGTH_SHORT).show(); return }
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n))).apply { putExtra("sms_body", message(c)); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        try { c.startActivity(i) } catch (e: Exception) { Toast.makeText(c, "SMS app nahi khula", Toast.LENGTH_SHORT).show() }
    }
    fun call(c: Context, n: String) {
        if (n.isBlank()) { Toast.makeText(c, "Number khaali hai", Toast.LENGTH_SHORT).show(); return }
        val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n))).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        try { c.startActivity(i) } catch (e: Exception) { Toast.makeText(c, "Dialer nahi khula", Toast.LENGTH_SHORT).show() }
    }
}

@Composable
fun SosDialog() {
    if (!SosBus.show) return
    val ctx = LocalContext.current
    var num by remember { mutableStateOf(Sos.number(ctx)) }
    Dialog(onDismissRequest = { SosBus.show = false }) {
        val shape = RoundedCornerShape(22.dp)
        Column(Modifier.fillMaxWidth().background(Color(0xFF120A12), shape).border(1.5.dp, Color(0xFFFF4D6D), shape).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("🚨 Emergency SOS", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Apna emergency contact number save karo. Location ke saath SMS aur call yahin se.", color = Color(0xFFB8C4DD), fontSize = 12.sp)
            OutlinedTextField(value = num, onValueChange = { num = it }, singleLine = true, label = { Text("Emergency contact number") }, modifier = Modifier.fillMaxWidth())
            Button({ Sos.save(ctx, num); Toast.makeText(ctx, "Number save ho gaya", Toast.LENGTH_SHORT).show() }, Modifier.fillMaxWidth()) { Text("💾 Number save karo") }
            Button({ Sos.save(ctx, num); Sos.sms(ctx) }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))) { Text("📍 Location SMS bhejo") }
            Button({ Sos.save(ctx, num); Sos.call(ctx, num) }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C))) { Text("📞 Contact ko call karo") }
            Button({ Sos.call(ctx, "112") }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7F0000))) { Text("🚑 112 Emergency call (India)") }
            Button({ SosBus.show = false }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF263238))) { Text("Band karo") }
        }
    }
}
