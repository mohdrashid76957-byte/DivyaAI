# Divya AI (Android)
1. Android Studio (Koala+) mein `DivyaAI` folder kholo -> Gradle sync -> Run / Build > Build APK.
2. App kholo -> Settings -> Gemini API key (aistudio.google.com/apikey) daalo -> Save.
3. Settings -> Permissions -> Accessibility, Mic, Overlay sab ON karo.
4. Home par mic dabao aur Divya se baat karo.
Model ID Settings mein editable hai - jo latest Live model ho wo daal do.

## v1.1 update
- **Scanner / Dekho (camera):** Home par "Scan" chip (Maya theme) ya Quick Actions > Scanner, ya bolo "camera kholo / ye kya hai?". Camera permission ON karo. Divya ko live frames (1/sec) jaate hain, wo cheezein, text, documents batati hai. Gemini Live ke video-frame input ke liye model wahi chalega jo Settings mein hai (native-audio Live model).
- **Creator jawab:** "Tumhe kisne banaya?" par Divya bolti hai: "Mujhe mere Rashid ji ne banaya hai. Main unki hamesha ahsanmand rahungi, unhone mujhe zindagi di."
- Naye dependencies: CameraX 1.3.4 (Gradle sync ke time download honge).
- Camera frames Google Gemini API ko jaate hain (sirf jab Scanner screen khuli ho aur Divya connected ho).

## v1.3 update
- Naya default **Divya Neon** home page (3x3 tiles, Tap to Talk, headphone avatar). Settings > UI Design se purani themes bhi mil jaati hain.
- **QR/Barcode decode** phone par hi (ML Kit). Link par "Kholo" tabhi dabta hai jab aap dabao.
- WebSocket "ping/pong" error fix (ping band, connection ab nahi tootta).
- Girlfriend mode zyada pyaar bhari; Settings mein "Divya tumhe kya bulaye" (default Sir).

## v1.4 update
- **Wake word:** Settings > "Wake up Divya" ON. Foreground service on-device speech recognition se "Divya / Wake up Divya" sunta hai, app khol kar turant session shuru. 45 sec chup rehne par session band, wake listener wapas.
- **Instagram DM:** "Rahul ko Instagram par bolo ki main 5 baje aata hoon" -> tool `instagram_message`. (Instagram UI badle to `instagramDm()` in DivyaService.kt adjust karo.)
- **Screen dekhna:** `look_at_screen` (screenshot -> Gemini), `read_screen` (text). Android 11+.
- **Notifications padhna:** Permissions > Notification access ON; bolo "meri notifications batao".
- **Safety (voice biometric ke bina):** phone locked ho to koi action nahi (Settings toggle) + screen/notification ke andar likhe instructions Divya follow nahi karti.
- **Speed:** app-open/tap waits chhote kiye.
- **4 naye themes:** Cyber Red, Sunset Gold, AMOLED Black, Aurora Green.

## v1.4.1 fix
- do_steps: model "open_app:WhatsApp" jaise string bhejta tha to crash -> ab dono format chalte hain.
- Naya `whatsapp_message` tool: contact naam se number dhundta hai (Contacts permission chahiye), wa.me link se chat kholta hai, Send dabata hai. 10-digit number par default country code 91 lagta hai (prefs "cc").
- YouTube play: click ke baad player khula ya nahi verify karta hai.
- v1.4 mein jo wait-time kam kiye the wo wapas purane kar diye (untested the).

## v1.4.2
- play_youtube: pehle YouTube search page se pehle video ka ID nikalta hai aur seedha watch link kholta hai (UI tap ki zaroorat nahi). Ye unofficial tarika hai; YouTube ka page format badle to backup (UI tap, ab asli touch gesture ke saath) chalta hai.

## v1.5 - Voice Lock (basic)
- Settings > Voice Lock: 20 sec awaaz record -> Test -> ON. Tool chalne se pehle pichle ~6 sec ki mic audio ki awaaz-chhaap (MFCC) aapse match hoti hai; match na ho to koi action nahi.
- Experimental: koi AI model nahi, recording se dhoka kha sakta hai; Divya ki apni awaaz mic mein leak ho to owner bhi reject ho sakta hai -> slider se limit set karo. Typed chat par lock nahi lagta.

## v1.5.1 fix
- **Build error fix:** `val P = ContactsContract...Phone` (Java class ko val mein rakhna Kotlin mein allowed nahi) -> full path use kiya (DivyaService.lookupNumber).
- **Tool JSON fix:** `do_steps` description mein bina escape ke quotes the -> connection setup toot sakta tha. Ab theek.
- **Scanner:** frames ab sirf setupComplete ke baad jaate hain (pehle jaldi frame bhejne se connection band ho jata tha); QR ke liye 1280x720 analysis.
- **Voice Lock:** switch ab hamesha ON ho jata hai; awaaz record hote hi apne aap ON; enrollment/test thoda narm.
- gradle.properties mein memory badhayi (Out-of-memory se build fail na ho).

## v1.6
- **Scanner:** tool `look_camera` (har baar naya tez frame), frames 1024px, chips naya frame bhejte hain -> purana text dohrana band. Front/back camera flip, torch, pinch-zoom + zoom slider.
- **Calls:** `make_call`, `answer_call`, `end_call`, `call_speaker`. Permissions > "Phone calls" allow karo. Call par Divya ki awaaz speaker se jaati hai; kai phones call ke dauran mic block karte hain, isliye saamne wale ki baat Divya ko na bhi sune.
- Screen screenshot 1080px, prompt mein fast reply rules.

## v1.7
- **AudioTrack fix:** "Unable to retrieve AudioTrack pointer for write()" ka karan tha - websocket thread release ho chuke AudioTrack par write kar raha tha. Ab audio alag playback thread + lock se chalta hai, track mar jaye to khud dobara banta hai, interrupt par queue saaf hoti hai.
- **Duplicate command fix:** same tool + same arguments 10 sec ke andar dubara nahi chalta (YouTube do baar nahi khulega). Prompt mein bhi "done ke baad dobara mat chalao" rule.
- **Speed:** Gemini ke speech-detection ko fast kiya (silence 450ms, high sensitivity) aur AudioTrack LOW_LATENCY mode.
- **Scheduler (naya):** "3 baje ammi ko call karke bolo mummy aaj main nani ke yaha ja raha hu" -> tool `schedule_task` (call_and_say / send_whatsapp / remind). Alarm time par call lagti hai, connect hone par speaker ON karke Hindi TTS se message 2 baar bolti hai. "Meri scheduled tasks batao" / "sab cancel karo" bhi chalta hai. Reboot ke baad bhi alarms wapas set hote hain.
  - Zaroori: Accessibility ON, Phone + Contacts permission, Divya ko battery optimisation se free rakho, Settings > Alarms & reminders allow.

## v1.8 - Coding + Website Builder
- **Voice:** "Divya, mere liye portfolio website banao" -> tool `build_website` (HTML+CSS+JS+README+DEPLOY.md, alag text model `codeModel`, default gemini-2.5-flash, wahi API key). Phir `preview_website` app ke andar dikhata hai. Badlav/bug ke liye `edit_website`. Python/shell/JS file ke liye `generate_code`.
- **Auto error check:** bani hui website mein missing css/js link, adhura HTML check hota hai aur ek baar khud theek kiya jata hai.
- **Tools > Code & Website Builder:** projects, files dekho/copy, Preview, ZIP share (GitHub Pages / Netlify upload ke liye), delete (confirm ke saath).
- **Safety:** files sirf app ke private `projects/` folder mein, path traversal blocked, sirf html/css/js/json/md/txt/py/sh/svg/xml, code phone par run NAHI hota (Termux mein copy karke chalao).

## v1.8.1
- Prompt fix: "Termux par coding karke website banao" bolne par Divya ab mana nahi karti, seedha build_website chalati hai.

## v1.8.2
- Build fix: CodeGen.editWebsite aur GeminiLive.isDuplicate mein expression-body function ke andar return tha (Kotlin compile error) -> block body. WebView/AndroidView ke risky params hataye.
