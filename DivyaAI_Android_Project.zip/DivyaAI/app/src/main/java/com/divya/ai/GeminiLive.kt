package com.divya.ai

import android.content.Context
import android.media.*
import android.os.Handler
import android.os.Looper
import android.util.Base64
import okhttp3.*
import okio.ByteString
import org.json.*
import java.util.concurrent.TimeUnit

/** Gemini Live API (WebSocket): mic PCM16k -> model, model PCM24k -> speaker, + phone-control tools. */
class GeminiLive(
    private val ctx: Context,
    private val onState: (String) -> Unit,
    private val onText: (String, Boolean) -> Unit,   // (text, startNewBubble)
    private val onHeard: (String) -> Unit = {}
) {
    private val main = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(20, TimeUnit.SECONDS).build()
    private var ws: WebSocket? = null
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    private var pending: String? = null
    private var mic = true
    private var newTurn = true
    @Volatile var running = false
    @Volatile var micOn = false

    private val prompt = "You are Divya, a warm, friendly female AI assistant. Speak Hinglish (Hindi+English) by default and call the user 'Boss'. " +
        "Keep replies very short. SPEED RULES for phone tasks: never narrate steps, never ask permission, act immediately. " +
        "Prefer ONE do_steps call with the whole sequence (open_app, tap, type, submit, scroll_down, wait...). " +
        "To play a song or video on YouTube ALWAYS call play_youtube(query) - it searches and plays by itself. If a step fails or you are unsure what is on screen, call read_screen, then continue. Speak only once at the end, in a few words."

    private val tools = """[
     {"name":"do_steps","description":"Run a full phone task in ONE call. steps = ordered list of {action,arg}. actions: play_youtube(arg=song/video to search and play), open_app(arg=app name), tap(arg=visible text/label), type(arg=text into focused input), submit (press enter/search/send), scroll_down, scroll_up, wait(arg=ms), home, back, recents, notifications, quick_settings, lock, screenshot","parameters":{"type":"OBJECT","properties":{"steps":{"type":"ARRAY","items":{"type":"OBJECT","properties":{"action":{"type":"STRING"},"arg":{"type":"STRING"}},"required":["action"]}}},"required":["steps"]}},
     {"name":"play_youtube","description":"Search YouTube for a song/video and play the first result automatically","parameters":{"type":"OBJECT","properties":{"query":{"type":"STRING"}},"required":["query"]}},
     {"name":"read_screen","description":"Read visible texts/buttons on the current screen"},
     {"name":"open_app","description":"Open an installed app by its name","parameters":{"type":"OBJECT","properties":{"app_name":{"type":"STRING"}},"required":["app_name"]}},
     {"name":"phone_action","description":"System action","parameters":{"type":"OBJECT","properties":{"action":{"type":"STRING","enum":["home","back","recents","notifications","quick_settings","lock","screenshot"]}},"required":["action"]}},
     {"name":"tap_text","description":"Tap a button/text visible on screen","parameters":{"type":"OBJECT","properties":{"text":{"type":"STRING"}},"required":["text"]}},
     {"name":"type_text","description":"Type text in the focused input field","parameters":{"type":"OBJECT","properties":{"text":{"type":"STRING"}},"required":["text"]}},
     {"name":"submit","description":"Press enter/search/send"},
     {"name":"scroll","description":"Scroll the current screen","parameters":{"type":"OBJECT","properties":{"direction":{"type":"STRING","enum":["up","down"]}},"required":["direction"]}}
    ]"""

    private fun state(s: String) = main.post { onState(s) }

    fun start(key: String, model: String, voice: String, withMic: Boolean = true, firstText: String? = null) {
        if (running) return
        running = true; mic = withMic; pending = firstText; newTurn = true
        state("Connecting…")
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key"
        ws = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) { w.send(setup(model, voice)) }
            override fun onMessage(w: WebSocket, text: String) = handle(text)
            override fun onMessage(w: WebSocket, bytes: ByteString) = handle(bytes.utf8())
            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) { stop("Error: ${t.message ?: r?.code}") }
            override fun onClosed(w: WebSocket, code: Int, reason: String) { stop(if (code == 1000) "Tap to Talk" else "Closed: $reason") }
        })
    }

    private fun setup(model: String, voice: String) = JSONObject().put("setup", JSONObject()
        .put("model", "models/$model")
        .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
            .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))
        .put("outputAudioTranscription", JSONObject())
        .put("inputAudioTranscription", JSONObject())
        .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", JSONArray(tools))))).toString()

    fun sendText(t: String) {
        ws?.send(JSONObject().put("clientContent", JSONObject()
            .put("turns", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", t)))))
            .put("turnComplete", true)).toString())
    }

    private fun handle(s: String) {
        try {
            val j = JSONObject(s)
            if (j.has("setupComplete")) {
                state(if (mic) "Listening…" else "Connected")
                initAudio(); pending?.let { sendText(it) }; pending = null
                if (mic) startMic()
            }
            j.optJSONObject("serverContent")?.let { sc ->
                if (sc.optBoolean("interrupted")) track?.flush()
                sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { ps ->
                    for (i in 0 until ps.length()) {
                        val d = ps.getJSONObject(i).optJSONObject("inlineData")?.optString("data")
                        if (!d.isNullOrEmpty()) { val b = Base64.decode(d, Base64.DEFAULT); track?.write(b, 0, b.size) }
                    }
                }
                sc.optJSONObject("outputTranscription")?.optString("text")?.takeIf { it.isNotBlank() }?.let {
                    val n = newTurn; newTurn = false; main.post { onText(it, n) }
                }
                sc.optJSONObject("inputTranscription")?.optString("text")?.takeIf { it.isNotBlank() }?.let { main.post { onHeard(it) } }
                if (sc.optBoolean("turnComplete")) newTurn = true
            }
            j.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { runTools(it) }
        } catch (e: Exception) { state("Error: ${e.message}") }
    }

    private val worker = java.util.concurrent.Executors.newSingleThreadExecutor()

    private fun runTools(arr: JSONArray) {
        // alag thread par chalao taaki websocket/audio na ruke aur UI ke wait fast rahein
        worker.execute {
            main.post { com.divya.ai.glow.GlowOverlay.setState(com.divya.ai.glow.GlowState.THINKING) }
            val out = JSONArray(); val svc = DivyaService.instance
            for (i in 0 until arr.length()) {
                val c = arr.getJSONObject(i); val a = c.optJSONObject("args") ?: JSONObject()
                val name = c.getString("name")
                val res: String = try {
                    fun yn(b: Boolean?) = if (b == true) "done" else "failed (not found or accessibility off)"
                    when (name) {
                        "open_app" -> { val o = Actions.openApp(ctx, a.optString("app_name")); if (o) svc?.waitOpen(Actions.lastPkg); yn(o) }
                        "phone_action" -> yn(svc?.global(a.optString("action")))
                        "tap_text" -> yn(svc?.tapText(a.optString("text")))
                        "type_text" -> yn(svc?.typeText(a.optString("text")))
                        "submit" -> yn(svc?.submit())
                        "scroll" -> yn(svc?.scroll(a.optString("direction")))
                        "play_youtube" -> svc?.playOnYoutube(a.optString("query")) ?: "accessibility off"
                        "read_screen" -> svc?.readScreen() ?: "accessibility off"
                        "do_steps" -> svc?.runSteps(a.optJSONArray("steps") ?: JSONArray()) ?: "accessibility off"
                        else -> "unknown tool"
                    }
                } catch (e: Exception) { "error: ${e.message}" }
                out.put(JSONObject().put("id", c.getString("id")).put("name", name)
                    .put("response", JSONObject().put("result", res)))
            }
            ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", out)).toString())
            main.post { com.divya.ai.glow.GlowOverlay.setState(if (micOn) com.divya.ai.glow.GlowState.LISTENING else com.divya.ai.glow.GlowState.SPEAKING) }
        }
    }

    private fun initAudio() {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(min * 4).setTransferMode(AudioTrack.MODE_STREAM).build().also { it.play() }
    }

    fun enableMic() { if (running && !micOn) { mic = true; startMic() } }

    @android.annotation.SuppressLint("MissingPermission")
    private fun startMic() {
        try {
            val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 4)
            if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); state("Mic start nahi hua: mic permission ya dusri app check karo"); return }
            try { if (android.media.audiofx.AcousticEchoCanceler.isAvailable()) android.media.audiofx.AcousticEchoCanceler.create(r.audioSessionId)?.enabled = true } catch (_: Exception) {}
            rec = r; r.startRecording(); micOn = true
            state("🎤 Bolo, Divya sun rahi hai…")
            Thread {
                val buf = ByteArray(1600)
                while (running && micOn) {
                    val n = r.read(buf, 0, buf.size)
                    if (n > 0) ws?.send("""{"realtimeInput":{"audio":{"mimeType":"audio/pcm;rate=16000","data":"${Base64.encodeToString(buf, 0, n, Base64.NO_WRAP)}"}}}""")
                    else if (n < 0) { state("Mic error $n"); break }
                }
            }.start()
        } catch (e: Exception) { state("Mic error: ${e.message}") }
    }

    fun stop(msg: String = "Tap to Talk") {
        if (!running) return
        running = false; micOn = false
        try { ws?.close(1000, null) } catch (_: Exception) {}
        try { rec?.stop(); rec?.release() } catch (_: Exception) {}
        try { track?.stop(); track?.release() } catch (_: Exception) {}
        rec = null; track = null; ws = null
        state(msg)
    }
}
