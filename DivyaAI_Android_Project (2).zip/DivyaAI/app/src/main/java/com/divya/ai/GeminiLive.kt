package com.divya.ai

import android.content.Context
import android.media.*
import android.os.Handler
import android.os.Looper
import android.util.Base64
import okhttp3.*
import okio.ByteString
import org.json.*
import java.util.concurrent.TimeUnit

/** Gemini Live API (WebSocket): mic PCM16k -> model, model PCM24k -> speaker, + phone-control tools. */
class GeminiLive(
    private val ctx: Context,
    private val onState: (String) -> Unit,
    private val onText: (String, Boolean) -> Unit   // (text, startNewBubble)
) {
    private val main = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(20, TimeUnit.SECONDS).build()
    private var ws: WebSocket? = null
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    private var pending: String? = null
    private var mic = true
    private var newTurn = true
    @Volatile var running = false

    private val prompt = "You are Divya, a warm, friendly female AI assistant. Speak Hinglish (Hindi+English) by default and call the user 'Boss'. " +
        "Keep replies short. When asked to open an app or control the phone, call the matching tool, then confirm."

    private val tools = """[
     {"name":"open_app","description":"Open an installed app by its name","parameters":{"type":"OBJECT","properties":{"app_name":{"type":"STRING"}},"required":["app_name"]}},
     {"name":"phone_action","description":"System action","parameters":{"type":"OBJECT","properties":{"action":{"type":"STRING","enum":["home","back","recents","notifications","quick_settings","lock","screenshot"]}},"required":["action"]}},
     {"name":"tap_text","description":"Tap a button/text visible on screen","parameters":{"type":"OBJECT","properties":{"text":{"type":"STRING"}},"required":["text"]}},
     {"name":"type_text","description":"Type text in the focused input field","parameters":{"type":"OBJECT","properties":{"text":{"type":"STRING"}},"required":["text"]}},
     {"name":"scroll","description":"Scroll the current screen","parameters":{"type":"OBJECT","properties":{"direction":{"type":"STRING","enum":["up","down"]}},"required":["direction"]}}
    ]"""

    private fun state(s: String) = main.post { onState(s) }

    fun start(key: String, model: String, voice: String, withMic: Boolean = true, firstText: String? = null) {
        if (running) return
        running = true; mic = withMic; pending = firstText; newTurn = true
        state("Connecting…")
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key"
        ws = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) { w.send(setup(model, voice)) }
            override fun onMessage(w: WebSocket, text: String) = handle(text)
            override fun onMessage(w: WebSocket, bytes: ByteString) = handle(bytes.utf8())
            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) { stop("Error: ${t.message ?: r?.code}") }
            override fun onClosed(w: WebSocket, code: Int, reason: String) { stop(if (code == 1000) "Tap to Talk" else "Closed: $reason") }
        })
    }

    private fun setup(model: String, voice: String) = JSONObject().put("setup", JSONObject()
        .put("model", "models/$model")
        .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
            .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))
        .put("outputAudioTranscription", JSONObject())
        .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", JSONArray(tools))))).toString()

    fun sendText(t: String) {
        ws?.send(JSONObject().put("clientContent", JSONObject()
            .put("turns", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", t)))))
            .put("turnComplete", true)).toString())
    }

    private fun handle(s: String) {
        try {
            val j = JSONObject(s)
            if (j.has("setupComplete")) {
                state(if (mic) "Listening…" else "Connected")
                initAudio(); pending?.let { sendText(it) }; pending = null
                if (mic) startMic()
            }
            j.optJSONObject("serverContent")?.let { sc ->
                if (sc.optBoolean("interrupted")) track?.flush()
                sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { ps ->
                    for (i in 0 until ps.length()) {
                        val d = ps.getJSONObject(i).optJSONObject("inlineData")?.optString("data")
                        if (!d.isNullOrEmpty()) { val b = Base64.decode(d, Base64.DEFAULT); track?.write(b, 0, b.size) }
                    }
                }
                sc.optJSONObject("outputTranscription")?.optString("text")?.takeIf { it.isNotBlank() }?.let {
                    val n = newTurn; newTurn = false; main.post { onText(it, n) }
                }
                if (sc.optBoolean("turnComplete")) newTurn = true
            }
            j.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { runTools(it) }
        } catch (_: Exception) {}
    }

    private fun runTools(arr: JSONArray) {
        val out = JSONArray(); val svc = DivyaService.instance
        for (i in 0 until arr.length()) {
            val c = arr.getJSONObject(i); val a = c.optJSONObject("args") ?: JSONObject()
            val ok = when (c.getString("name")) {
                "open_app" -> Actions.openApp(ctx, a.optString("app_name"))
                "phone_action" -> svc?.global(a.optString("action")) == true
                "tap_text" -> svc?.tapText(a.optString("text")) == true
                "type_text" -> svc?.typeText(a.optString("text")) == true
                "scroll" -> svc?.scroll(a.optString("direction")) == true
                else -> false
            }
            out.put(JSONObject().put("id", c.getString("id")).put("name", c.getString("name"))
                .put("response", JSONObject().put("result", if (ok) "done" else "failed (app not found or accessibility off)")))
        }
        ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", out)).toString())
    }

    private fun initAudio() {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(min * 4).setTransferMode(AudioTrack.MODE_STREAM).build().also { it.play() }
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun startMic() {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
        rec = r; r.startRecording()
        Thread {
            val buf = ByteArray(3200)
            while (running) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0) ws?.send("""{"realtimeInput":{"audio":{"mimeType":"audio/pcm;rate=16000","data":"${Base64.encodeToString(buf, 0, n, Base64.NO_WRAP)}"}}}""")
            }
        }.start()
    }

    fun stop(msg: String = "Tap to Talk") {
        if (!running) return
        running = false
        try { ws?.close(1000, null) } catch (_: Exception) {}
        try { rec?.stop(); rec?.release() } catch (_: Exception) {}
        try { track?.stop(); track?.release() } catch (_: Exception) {}
        rec = null; track = null; ws = null
        state(msg)
    }
}
