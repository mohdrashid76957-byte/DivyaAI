package com.divya.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

enum class Screen { Home, Chat, Apps, Quick, Automate, Phone, Settings, Perms }

class UiTheme(
    val name: String, val img: Int, val circle: Boolean, val bg: Brush, val text: Color, val accent: Color,
    val greet: String, val menu: List<Triple<String, Screen, ImageVector>>
)

val themes = listOf(
    UiTheme("Neon Blue", R.drawable.divya_dark, true,
        Brush.verticalGradient(listOf(Color(0xFF020B2D), Color(0xFF0A2A7A))), Color.White, Color(0xFF29B6FF),
        "Hello Boss! 👋\nHow can I help you today?",
        listOf(Triple("Quick Actions", Screen.Quick, Icons.Filled.FlashOn), Triple("Open Apps", Screen.Apps, Icons.Filled.Apps),
            Triple("Phone Control", Screen.Phone, Icons.Filled.PhoneAndroid), Triple("More", Screen.Settings, Icons.Filled.Star))),
    UiTheme("Lavender Light", R.drawable.divya_light, true,
        Brush.verticalGradient(listOf(Color(0xFFE6DCFF), Color(0xFFF8F5FF))), Color(0xFF2B1B5E), Color(0xFF6C3CE9),
        "Hi! I'm Divya 😊\nLet's chat, talk or get things done!",
        listOf(Triple("Chat", Screen.Chat, Icons.Filled.Chat), Triple("Apps", Screen.Apps, Icons.Filled.Apps),
            Triple("Automate", Screen.Automate, Icons.Filled.FlashOn), Triple("Settings", Screen.Settings, Icons.Filled.Settings))),
    UiTheme("Purple Full", R.drawable.divya_full, false,
        Brush.verticalGradient(listOf(Color(0xFF0A0630), Color(0xFF3B1A8C))), Color.White, Color(0xFFB07CFF),
        "Hello Boss!\nI'm Divya,\nYour AI Assistant ❤️",
        listOf(Triple("Home", Screen.Home, Icons.Filled.Home), Triple("Chat", Screen.Chat, Icons.Filled.Chat),
            Triple("Automations", Screen.Automate, Icons.Filled.SmartToy), Triple("Settings", Screen.Settings, Icons.Filled.Settings)))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) { super.onCreate(s); setContent { MaterialTheme { DivyaApp(this) } } }
}

fun a11yOn(c: Context) = (Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(c.packageName)
fun micOk(c: Context) = c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

@Composable
fun DivyaApp(ctx: Context) {
    val prefs = remember { ctx.getSharedPreferences("divya", 0) }
    var themeIdx by remember { mutableStateOf(prefs.getInt("theme", 0)) }
    var screen by remember { mutableStateOf(Screen.Home) }
    var status by remember { mutableStateOf("Tap to Talk") }
    val msgs = remember { mutableStateListOf<Pair<String, String>>() }
    val live = remember {
        GeminiLive(ctx, { status = it }, { t, n ->
            if (n || msgs.lastOrNull()?.first != "Divya") msgs.add("Divya" to t)
            else msgs[msgs.lastIndex] = "Divya" to (msgs.last().second + t)
        })
    }
    val th = themes[themeIdx]
    fun key() = prefs.getString("key", "") ?: ""
    fun model() = prefs.getString("model", "gemini-2.5-flash-native-audio-preview-09-2025")!!
    fun voice() = prefs.getString("voice", "Aoede")!!

    fun toggle() {
        if (live.running) { live.stop(); return }
        if (key().isBlank()) { status = "Settings mein Gemini API key daalo"; screen = Screen.Settings; return }
        live.start(key(), model(), voice(), true)
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) toggle() }
    val tapMic = { if (micOk(ctx)) toggle() else micLauncher.launch(Manifest.permission.RECORD_AUDIO) }

    BackHandler(screen != Screen.Home) { screen = Screen.Home }
    Column(Modifier.fillMaxSize().background(th.bg).systemBarsPadding()) {
        Box(Modifier.weight(1f)) {
            when (screen) {
                Screen.Home -> Home(th, status, live.running, tapMic)
                Screen.Chat -> ChatScreen(th, msgs) { t ->
                    msgs.add("You" to t)
                    if (live.running) live.sendText(t)
                    else if (key().isBlank()) { status = "API key missing"; screen = Screen.Settings }
                    else live.start(key(), model(), voice(), false, t)
                }
                Screen.Apps -> AppsScreen(th, ctx)
                Screen.Quick -> QuickScreen(th, ctx)
                Screen.Automate -> AutomateScreen(th)
                Screen.Phone -> PhoneScreen(th, ctx) { screen = Screen.Perms }
                Screen.Settings -> SettingsScreen(th, prefs, themeIdx, { themeIdx = it; prefs.edit().putInt("theme", it).apply() }) { screen = Screen.Perms }
                Screen.Perms -> PermsScreen(th, ctx)
            }
        }
        Row(Modifier.fillMaxWidth().padding(10.dp).clip(RoundedCornerShape(22.dp))
            .background(th.accent.copy(alpha = 0.18f)).padding(vertical = 8.dp), Arrangement.SpaceEvenly) {
            th.menu.forEach { (label, target, icon) ->
                Column(Modifier.clickable { screen = target }.padding(horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(icon, label, tint = if (screen == target) th.accent else th.text)
                    Text(label, color = th.text, fontSize = 11.sp, textAlign = TextAlign.Center)
                }
            }
        }
    }
}

@Composable
fun Home(th: UiTheme, status: String, live: Boolean, onMic: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceEvenly) {
        Text("Divya AI", color = th.text, fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("— Your Voice, My World —", color = th.accent, fontSize = 14.sp)
        if (th.circle)
            Image(painterResource(th.img), "Divya", Modifier.size(210.dp).clip(CircleShape).border(3.dp, th.accent, CircleShape), contentScale = ContentScale.Crop)
        else
            Image(painterResource(th.img), "Divya", Modifier.weight(1f).fillMaxWidth(), contentScale = ContentScale.Fit)
        Box(Modifier.clip(RoundedCornerShape(18.dp)).background(th.accent.copy(alpha = 0.2f)).border(1.dp, th.accent, RoundedCornerShape(18.dp)).padding(14.dp)) {
            Text(th.greet, color = th.text, textAlign = TextAlign.Center)
        }
        Box(Modifier.size(92.dp).clip(CircleShape).background(if (live) Color(0xFFE53935) else th.accent.copy(alpha = 0.3f))
            .border(3.dp, th.accent, CircleShape).clickable { onMic() }, contentAlignment = Alignment.Center) {
            Icon(if (live) Icons.Filled.Stop else Icons.Filled.Mic, "Talk", tint = Color.White, modifier = Modifier.size(44.dp))
        }
        Text(if (live && status == "Tap to Talk") "Listening…" else status, color = th.accent, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Page(th: UiTheme, title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, color = th.text, fontSize = 26.sp, fontWeight = FontWeight.Bold); content()
    }
}

@Composable
fun Btn(th: UiTheme, label: String, onClick: () -> Unit) =
    Button(onClick, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = th.accent)) { Text(label, color = Color.White) }

@Composable
fun ChatScreen(th: UiTheme, msgs: List<Pair<String, String>>, send: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs) { (who, txt) ->
                val me = who == "You"
                Box(Modifier.fillMaxWidth(), contentAlignment = if (me) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(txt, color = th.text, modifier = Modifier.clip(RoundedCornerShape(14.dp))
                        .background(th.accent.copy(alpha = if (me) 0.45f else 0.2f)).padding(10.dp))
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(t, { t = it }, Modifier.weight(1f), placeholder = { Text("Divya se chat karo…") },
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = th.text, unfocusedTextColor = th.text))
            IconButton({ if (t.isNotBlank()) { send(t.trim()); t = "" } }) { Icon(Icons.Filled.Send, "Send", tint = th.accent) }
        }
    }
}

@Composable
fun AppsScreen(th: UiTheme, ctx: Context) {
    val pm = ctx.packageManager
    val apps = remember { pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        .map { it.loadLabel(pm).toString() }.distinct().sorted() }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Open Apps", color = th.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        LazyColumn { items(apps) { n ->
            Text(n, color = th.text, modifier = Modifier.fillMaxWidth().clickable { Actions.openApp(ctx, n) }.padding(vertical = 12.dp))
            HorizontalDivider(color = th.accent.copy(alpha = 0.3f))
        } }
    }
}

@Composable
fun QuickScreen(th: UiTheme, ctx: Context) = Page(th, "Quick Actions") {
    listOf("Home" to "home", "Back" to "back", "Recent Apps" to "recents", "Notifications" to "notifications",
        "Quick Settings" to "quick_settings", "Screenshot" to "screenshot", "Lock Screen" to "lock").forEach { (l, a) ->
        Btn(th, l) {
            val s = DivyaService.instance
            if (s == null) Toast.makeText(ctx, "Pehle Accessibility permission ON karo", Toast.LENGTH_LONG).show() else s.global(a)
        }
    }
}

@Composable
fun AutomateScreen(th: UiTheme) = Page(th, "Automations") {
    Text("Mic dabake bolo, Divya khud kaam karegi:", color = th.text)
    listOf("“YouTube kholo”", "“Notifications dikhao”", "“Neeche scroll karo”", "“Search box mein 'lofi songs' likho”",
        "“Settings kholo aur Wi-Fi par tap karo”", "“Screenshot lo”", "“Phone lock kar do”").forEach {
        Text(it, color = th.text, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(th.accent.copy(alpha = 0.2f)).padding(12.dp))
    }
}

@Composable
fun PhoneScreen(th: UiTheme, ctx: Context, openPerms: () -> Unit) = Page(th, "Phone Control") {
    Text(if (a11yOn(ctx)) "✅ Accessibility ON — Divya phone control kar sakti hai" else "⚠️ Accessibility OFF — Divya phone control nahi kar paegi", color = th.text)
    Btn(th, "Permissions kholo", openPerms)
}

@Composable
fun SettingsScreen(th: UiTheme, prefs: android.content.SharedPreferences, themeIdx: Int, setTheme: (Int) -> Unit, openPerms: () -> Unit) = Page(th, "Settings") {
    var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "gemini-2.5-flash-native-audio-preview-09-2025")!!) }
    var voice by remember { mutableStateOf(prefs.getString("voice", "Aoede")!!) }
    var saved by remember { mutableStateOf(false) }
    val colors = OutlinedTextFieldDefaults.colors(focusedTextColor = th.text, unfocusedTextColor = th.text)
    Text("Gemini API Key", color = th.accent, fontWeight = FontWeight.Bold)
    OutlinedTextField(key, { key = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("API key") },
        visualTransformation = PasswordVisualTransformation(), singleLine = true, colors = colors)
    OutlinedTextField(model, { model = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("Live voice model ID (latest daal sakte ho)") }, colors = colors)
    OutlinedTextField(voice, { voice = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("Female voice (Aoede / Kore / Leda / Zephyr)") }, colors = colors)
    Btn(th, "Save") { prefs.edit().putString("key", key.trim()).putString("model", model.trim()).putString("voice", voice.trim()).apply(); saved = true }
    if (saved) Text("✅ Saved", color = th.accent)
    Text("UI Design", color = th.accent, fontWeight = FontWeight.Bold)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        themes.forEachIndexed { i, t -> FilterChip(themeIdx == i, { setTheme(i) }, { Text(t.name, fontSize = 11.sp) }) }
    }
    Btn(th, "Permissions") { openPerms() }
}

@Composable
fun PermsScreen(th: UiTheme, ctx: Context) {
    var tick by remember { mutableStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
    }
    val micL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val notiL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    fun go(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    key(tick) {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val rows = listOf(
            Triple("Accessibility (phone control + apps kholna)", a11yOn(ctx)) { go(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            Triple("Microphone (voice baat)", micOk(ctx)) { micL.launch(Manifest.permission.RECORD_AUDIO) },
            Triple("Display over other apps (background mein apps kholna)", Settings.canDrawOverlays(ctx)) {
                go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))) },
            Triple("Notifications", Build.VERSION.SDK_INT < 33 || ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= 33) notiL.launch(Manifest.permission.POST_NOTIFICATIONS) },
            Triple("Battery optimization OFF (background chalne ke liye)", pm.isIgnoringBatteryOptimizations(ctx.packageName)) {
                go(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))) }
        )
        Page(th, "Permissions") {
            rows.forEach { (label, ok, act) ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(th.accent.copy(alpha = 0.18f)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(label, color = th.text, modifier = Modifier.weight(1f))
                    if (ok) Text("✅", fontSize = 20.sp) else Button(act, colors = ButtonDefaults.buttonColors(containerColor = th.accent)) { Text("Allow") }
                }
            }
            Text("Accessibility: Settings → Installed apps → Divya AI → ON karo.", color = th.text, fontSize = 12.sp)
        }
    }
}
