package com.divya.ai

import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.media.*
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Video Gen ki live state (screen aur voice tool dono yahin se progress dikhate hain). */
object VideoBus {
    var busy by mutableStateOf(false)
    var stage by mutableStateOf("")
    var error by mutableStateOf<String?>(null)
    var lastPath by mutableStateOf<String?>(null)
    /** Voice se video bani to Video screen khulwane ke liye. */
    var openTick by mutableStateOf(0)
    /** Instant live preview (mp4 export background mein chalti rehti hai). */
    var live by mutableStateOf<VideoGen.Live?>(null)
}

/**
 * Topic bolo -> 9:16 video (720x1280): Gemini script, phone ki Hindi/English TTS awaaz, subtitles, background visuals.
 * Sab phone par hi encode hota hai (MediaCodec + MediaMuxer), koi extra library nahi. Visuals: Pexels free key ho to
 * asli photos (Settings: "pexelsKey"), warna neon animated background.
 */
object VideoGen {
    private const val TAG = "DivyaVideoGen"
    const val W = 720      // encode size: HD 9:16
    const val H = 1280
    const val FPS = 24     // 15 se 24: camera move smooth, "slideshow" jaisa nahi lagta
    private const val IW = 720   // AI image ka size = video ke barabar (pehle 576x1024 thi aur upscale hoke dhundhli lagti thi)
    private const val IH = 1280
    @Volatile private var refBmp: Bitmap? = null     // scene 1 ki image: baaki scenes mein SAME character rakhne ke liye
    @Volatile private var gDead = false              // Gemini image quota/permission band ho to baar-baar mat try karo
    private const val DW = 720f   // design space (drawing coordinates)
    private const val DH = 1280f

    /** Sad / shayari / emotional style: dark moody photo band + serif text + halka sad music (Instagram sad reel jaisa). */
    fun isSad(st: String): Boolean { val x = st.lowercase(); return x.contains("sad") || x.contains("shayari") || x.contains("emotional") || x.contains("breakup") }

    class Scene(val speak: String, val caption: String, val query: String, val img: String = "")
    class Plan(val title: String, val scenes: List<Scene>, val character: String = "", val style: String = "") { val sad: Boolean = isSad(style) }
    class Result(val path: String, val title: String, val seconds: Int, val scenes: Int, val visuals: String)
    private class Pcm(val sr: Int, val s: ShortArray)
    class Live(val renderer: Renderer, val total: Double, val startNs: Long) { var track: AudioTrack? = null }

    @Volatile private var imgErr = ""
    private val imgHttp = OkHttpClient.Builder().connectTimeout(10, TimeUnit.SECONDS).readTimeout(75, TimeUnit.SECONDS).build()
    private val http = OkHttpClient.Builder().connectTimeout(5, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build()

    fun dir(c: Context): File = (c.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: File(c.filesDir, "videos")).also { it.mkdirs() }
    fun list(c: Context): List<File> = dir(c).listFiles { f -> f.extension == "mp4" }?.sortedByDescending { it.lastModified() } ?: emptyList()

    /** UI aur voice dono yahin se. Result string Live model ko jata hai ("done: ..." / "failed: ..."). */
    fun createTracked(c: Context, topic: String, lang: String, secs: Int, style: String, script: String = "", captions: String = "", visuals: String = "auto"): String {
        if (VideoBus.busy) return "failed: ek video pehle se ban rahi hai, thoda ruko."
        VideoBus.busy = true; VideoBus.error = null; VideoBus.stage = "Shuru…"
        return try {
            val r = create(c, topic, lang, secs, style, script, captions, visuals) { s -> VideoBus.stage = s; BgTasks.stage(s) }
            VideoBus.lastPath = r.path
            "done: video '${r.title}' ready (${r.seconds} sec, ${r.scenes} scenes, visuals: ${r.visuals}). Phone mein Movies/DivyaVideos mein save hai aur Video screen mein dikh rahi hai - wahan se Share kar sakte ho."
        } catch (e: Throwable) {
            Log.e(TAG, "video fail", e)
            VideoBus.error = e.message ?: e.javaClass.simpleName
            "failed: ${VideoBus.error}"
        } finally {
            VideoBus.live?.track?.let { try { it.stop(); it.release() } catch (_: Exception) {} }
            VideoBus.live = null; VideoBus.busy = false; VideoBus.stage = ""
        }
    }

    fun create(c: Context, topic: String, lang: String, secs: Int, style: String, script: String, captions: String, visuals: String, onStage: (String) -> Unit): Result {
        require(topic.isNotBlank()) { "Topic khali hai" }
        val t0 = System.currentTimeMillis()
        val seconds = secs.coerceIn(10, 60)
        val isEn = lang.startsWith("en", true)
        val prefs = c.getSharedPreferences("divya", 0)
        val pexels = prefs.getString("pexelsKey", "")?.trim() ?: ""
        // auto = Pexels key ho to ASLI stock video footage (sabse real), warna AI images. "real" bina key ke ho to AI images.
        val mode = when (visuals) { "fast", "instant" -> "fast"; "ai" -> "ai"; else -> if (pexels.isNotBlank()) "real" else "ai" }
        val real = mode == "real"
        val ai = mode != "fast"
        imgErr = ""; refBmp = null; gDead = false
        if (visuals == "real" && pexels.isBlank()) onStage("Pexels key nahi hai (Settings mein free key daalo), AI images se bana rahi hoon…")
        val plan = (if (!ai) localPlan(topic.trim(), script, captions, style) else null) ?: run { onStage(if (real) "Scenes likh rahi hoon…" else if (ai) "Kahani aur scenes likh rahi hoon…" else "Script likh rahi hoon…"); writePlan(c, topic.trim(), isEn, seconds, style, ai, real) }

        // visuals background threads mein (real clips / AI images / photos), TTS saath-saath
        val src = prefs.getString("vgImg", "auto") ?: "auto"
        val seed = (System.currentTimeMillis() % 90000).toInt() + 1000
        // SPEED: saari scenes ki images ek saath (parallel). Jaise hi ek image tayyar hoti hai wo `shared` list mein aa jati hai
        // aur live preview use turant dikha deta hai -> preview ko saari images ka intezaar nahi karna padta.
        val pool = Executors.newFixedThreadPool(if (ai) min(3, plan.scenes.size).coerceAtLeast(1) else 3)   // 8 saath mein bhejne se free server rok deta tha -> baaki scenes mein wahi ek image repeat hoti thi
        val first = java.util.concurrent.CountDownLatch(1)
        val used = java.util.Collections.synchronizedSet(mutableSetOf<Long>())
        val shared: MutableList<Bitmap?> = java.util.Collections.synchronizedList(MutableList<Bitmap?>(plan.scenes.size) { null })
        val clipFiles: MutableList<File?> = java.util.Collections.synchronizedList(MutableList<File?>(plan.scenes.size) { null })
        val usedVid = java.util.Collections.synchronizedSet(mutableSetOf<Long>())
        val futs: List<Future<Bitmap?>> = plan.scenes.mapIndexed { i, s ->
            pool.submit<Bitmap?> {
                val clip: File? = if (real) { try { fetchClip(c, pexels, s.query, i, plan.sad, usedVid) } catch (e: Exception) { imgErr = "clip: ${e.message}"; Log.w(TAG, "clip: ${e.message}"); null } } else null
                if (clip != null) { clipFiles[i] = clip; if (i == 0) first.countDown(); null }
                else {
                    if (ai && !real && i > 0) { try { first.await(50, java.util.concurrent.TimeUnit.SECONDS) } catch (_: InterruptedException) {} }   // pehle scene ke baad baaki, taaki character same rahe
                    val b = try { if (ai) aiImage(c, plan, s, seed, src, pexels, used) else if (pexels.isBlank()) null else fetchPhoto(pexels, s.query, used) }
                            finally { if (i == 0) first.countDown() }
                    if (b != null) { shared[i] = b; if (i == 0 && !real) refBmp = b }
                    b
                }
            }
        }

        onStage("Awaaz bana rahi hoon…")
        val voices = try { synth(c, plan.scenes, isEn, if (plan.style.isNotBlank()) plan.style else style.lowercase()) } catch (e: Throwable) { pool.shutdownNow(); throw e }
        // Preview shuru karne se pehle sirf PEHLI image ka thoda intezaar (max 4 sec). Baaki images video chalte-chalte aati rahengi.
        val firstDl = System.currentTimeMillis() + (if (ai) 45_000L else 1_500L)   // AI mode: pehli asli image aane tak ruko, neon preview kabhi nahi
        while (System.currentTimeMillis() < firstDl && (if (ai) !futs[0].isDone else futs.any { !it.isDone })) {
            if (ai) onStage("Pehla scene ban raha hai…")
            try { Thread.sleep(80) } catch (_: InterruptedException) { break }
        }

        val sr = voices.first().sr
        val lead = (sr * (if (plan.sad) 0.6 else 0.12)).toInt(); val tail = (sr * (if (plan.sad) 1.0 else 0.30)).toInt()   // sad: lines ko saans lene do
        val starts = ArrayList<Double>(); val durs = ArrayList<Double>(); val speakDur = ArrayList<Double>()
        var total = 0
        val pcmAll = ArrayList<Short>(sr * seconds)
        voices.forEach { v ->
            val pcm = if (v.sr == sr) v.s else resample(v.s, v.sr, sr)
            starts.add(total.toDouble() / sr)
            repeat(lead) { pcmAll.add(0) }
            pcm.forEach { pcmAll.add(it) }
            repeat(tail) { pcmAll.add(0) }
            val n = lead + pcm.size + tail
            durs.add(n.toDouble() / sr); speakDur.add(pcm.size.toDouble() / sr)
            total += n
        }
        val audio = ShortArray(pcmAll.size) { pcmAll[it] }
        if (plan.sad) mixSadMusic(audio, sr)
        val totalSec = total.toDouble() / sr

        // INSTANT: awaaz + live video preview abhi shuru, mp4 export peeche chalti rahegi
        // Preview `shared` list se chalta hai: jo images baad mein aati hain wo apne aap dikhne lagti hain.
        val live: Live? = if (real) null else Live(Renderer(plan, shared, starts, durs, speakDur), totalSec, System.nanoTime())   // real clips: live preview nahi (UI thread par decode atakta), seedha export
        if (live != null) { live.track = playAudio(audio, sr); VideoBus.live = live }
        Handler(Looper.getMainLooper()).post { VideoBus.openTick++ }
        val tmpV = File(c.cacheDir, "vg_v.mp4"); val tmpA = File(c.cacheDir, "vg_a.m4a")
        tmpV.delete(); tmpA.delete()
        var audioErr: Throwable? = null
        val aThread = Thread { try { encodeAudio(audio, sr, tmpA) } catch (e: Throwable) { audioErr = e } }.also { it.start() }

        // mp4 export ke liye baaki images ka intezaar (preview isse nahi rukta)
        if (ai) {
            val dl = System.currentTimeMillis() + (if (real) 150_000L else 70_000L)
            while (futs.any { !it.isDone } && System.currentTimeMillis() < dl) {
                onStage(if (real) "Asli video clips download ho rahi hain… ${futs.count { it.isDone }}/${futs.size}" else "Baaki AI images aa rahi hain… ${futs.count { it.isDone }}/${futs.size}")
                try { Thread.sleep(200) } catch (_: InterruptedException) { break }
            }
        }
        pool.shutdownNow()
        // Jis scene ki image nahi aayi use ek-ek karke dobara banao (max 75 sec), taaki ek hi photo har scene mein na dikhe
        if (ai) {
            val retryEnd = System.currentTimeMillis() + 75_000L
            for (i in plan.scenes.indices) {
                if (shared[i] != null || clipFiles[i] != null || System.currentTimeMillis() > retryEnd) continue
                onStage("Scene ${i + 1} ki image dobara bana rahi hoon…")
                val b = try { aiImage(c, plan, plan.scenes[i], seed + 7 * i, src, pexels, used) } catch (_: Exception) { null }
                if (b != null) shared[i] = b
            }
        }
        if (ai && shared.all { it == null } && clipFiles.all { it == null }) {
            // Pehle yahan chupke se neon video ban jati thi. Ab saaf error.
            throw CodeGen.GenError("AI images nahi bani (${imgErr.ifBlank { "internet/server jawab nahi diya" }}). Internet check karo, Video Gen > Settings mein image source 'Gemini' ya 'Free AI' try karo, phir dobara banao.")
        }
        val bmps: List<Bitmap?> = fillGaps(ArrayList(shared))
        onStage("Video encode ho rahi hai…")
        val visualsTxt = if (clipFiles.any { it != null }) "real video clips (Pexels)" else if (bmps.any { it != null }) (if (ai) "AI images" else "photos") else (if (ai) "neon (AI image nahi bani: $imgErr)" else "neon animated")
        encodeVideo(plan, bmps, starts, durs, speakDur, totalSec, tmpV, ArrayList(clipFiles)) { p -> onStage("Video encode… ${(p * 100).toInt()}%") }

        aThread.join(); audioErr?.let { throw it }
        onStage("Awaaz + video jod rahi hoon…")
        val name = "divya_" + java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date()) + ".mp4"
        val out = File(dir(c), name)
        merge(tmpV, tmpA, out)
        tmpV.delete(); tmpA.delete()
        Thread { try { saveToGallery(c, out) } catch (e: Exception) { Log.w(TAG, "gallery save", e) } }.start()
        // title ko bhi saath rakhne ke liye chhota sidecar
        try { File(out.path + ".txt").writeText(plan.title + "\n" + plan.scenes.joinToString("\n") { it.caption }) } catch (_: Exception) {}
        // preview khatam hone tak ruko taaki screen par awaaz do baar na chale
        val rem = if (live == null) 0L else ((totalSec * 1e9 - (System.nanoTime() - live.startNs)) / 1e6).toLong().coerceIn(0, 60_000)
        if (rem > 0) try { Thread.sleep(rem) } catch (_: InterruptedException) {}
        for (f in clipFiles) f?.delete()
        Log.i(TAG, "video ready in ${(System.currentTimeMillis() - t0) / 1000.0}s")
        return Result(out.absolutePath, plan.title, totalSec.toInt(), plan.scenes.size, visualsTxt)
    }

    // ------------------------------------------------------------------ SCRIPT
    /** Divya (Live model) ne script khud bheji ho ("scene1 | scene2 | ...") to alag Gemini call ki zaroorat nahi -> 2-5 sec bachte hain. */
    private fun localPlan(topic: String, script: String, captions: String, style: String): Plan? {
        val sp = script.split("|").map { it.trim() }.filter { it.isNotEmpty() }.take(8)
        if (sp.isEmpty()) return null
        val cp = captions.split("|").map { it.trim() }
        return Plan(topic.take(40).ifBlank { "Video" }, sp.mapIndexed { i, t -> Scene(t, cp.getOrNull(i)?.takeIf { it.isNotEmpty() } ?: t, topic) }, "", style.lowercase())
    }

    private fun writePlan(c: Context, topic: String, en: Boolean, seconds: Int, style: String, ai: Boolean, real: Boolean = false): Plan {
        val n = if (ai) (seconds / 5).coerceIn(3, 12) else (seconds / 6).coerceIn(2, 7)
        val words = (seconds * if (en) 2.4 else 2.2).toInt()
        val sys = "You write scripts for short vertical social videos (Reels/Shorts). Reply ONLY with JSON."
        val langRule = if (en) "Narration in simple spoken English. caption = same text as speak."
        else "speak = narration in HINDI written in DEVANAGARI script (natural spoken Hindi, simple words, a little English words allowed in Devanagari). caption = the SAME sentence written in Hinglish (Roman letters) for subtitles."
        val sadMode = isSad(style)
        val user = if (real) """Topic / idea: $topic
Style: ${style.ifBlank { "facts" }}. Make a viral-style short vertical reel (Instagram Reels / YouTube Shorts) that uses REAL STOCK VIDEO FOOTAGE as the background.
Make exactly $n scenes of about 5 seconds each, about $words words of narration in total.
$langRule
Scene 1 narration = a shocking hook or curiosity question that stops the scroll; then short punchy spoken sentences (under 14 words each) that build curiosity; last scene = punchy ending + follow/like. ${if (sadMode) "Mood: sad, lonely, heart-touching shayari-like lines, the emotion grows scene by scene; never encourage self-harm, no abuse." else "Funny = quick jokes, attitude = bold swag lines but never abuse, hate or threats."}
query = 2-4 simple English words to search a free stock VIDEO site for a REAL footage clip that matches the scene. Use concrete, common, filmable things that really exist as stock footage (e.g. "man walking rain night", "city traffic night", "ocean waves sunset", "hands typing laptop", "crowd walking street"). ${if (sadMode) "Always dark / night / rain / lonely mood footage (e.g. \"lonely man night street\", \"rain window night\", \"motorcycle night city\")." else "Each scene a clearly different subject."} No brand names or people names.
JSON format: {"title":"short title (max 6 words)","scenes":[{"speak":"...","caption":"...","query":"..."}]}""" else if (ai && sadMode) """Idea: $topic
Make a SAD / EMOTIONAL reel like popular Instagram sad-status reels: dark, lonely, heartbroken but gentle mood.
Make exactly $n scenes of about 5 seconds each.
$langRule
speak = ONE or TWO short heart-touching lines per scene (max 12 words), like sad shayari or an inner monologue; the emotion grows scene by scene; the last scene = one hard-hitting closing line. Sad but never encourage self-harm or suicide, no abuse.
"character" = ONE English description of a single lonely person seen from behind, in silhouette or with the face partly hidden (e.g. "a lone young man in a black hoodie and black helmet"), identical in every scene. Use "" if there is no person.
Each scene "image" = a detailed English prompt for a DARK, moody, cinematic NIGHT photograph (rainy empty street, lone rider under streetlights, rain on a window, empty bench, foggy road, city lights bokeh, silhouette at a railing), low-key lighting, muted colours. Every scene a different place or camera angle. No text in the image.
JSON format: {"title":"short title (max 6 words)","character":"...","scenes":[{"speak":"...","caption":"...","image":"..."}]}""" else if (ai) """Topic / story idea: $topic
Style: ${style.ifBlank { "story" }}. Make a viral-style short video reel. If the style is "story" (or the idea names characters) make it a CINEMATIC STORY with a consistent main character. If the style is facts / funny / attitude / motivation, still show REAL-LOOKING visuals that literally illustrate each line (real places, objects, people, close-ups of the subject) - never abstract backgrounds.
Scene 1 narration = a shocking hook or curiosity question that stops the scroll; middle scenes build curiosity with short punchy spoken sentences (under 14 words each); last scene = punchy ending + follow/like. Funny = quick jokes, attitude = bold swag lines but never abuse, hate or threats.
Make exactly $n scenes of about 5 seconds each, about $words words of narration in total.
$langRule
"character" = ONE detailed English visual description of the main character(s), identical in every scene (species/age/clothes/colours/accessories, e.g. "a cute white lion cub wearing a white linen shirt and a thin gold chain"). Use "" if there is no character.
Each scene "image" = a detailed English prompt for a PHOTOREALISTIC cinematic still: camera angle, location, lighting, what the character is doing. Every scene must be a clearly DIFFERENT location or camera angle (wide, close-up, over-the-shoulder, aerial, low angle) with real-looking details (props, background, time of day) - never repeat the same shot. Always mention the character. No text, logos or captions inside the image.
Scene 1 = strong hook. Last scene = short ending / follow-like call to action.
JSON format: {"title":"short title (max 6 words)","character":"...","scenes":[{"speak":"...","caption":"...","image":"..."}]}""" else """Topic: $topic
Style: ${style.ifBlank { "facts" }}
Make exactly $n scenes, about $words words of narration in total (about $seconds seconds when spoken).
$langRule
Scene 1 must be a strong hook (question or surprising fact). Last scene: short call to action (follow/like).
query = 2-4 English words describing a good background stock photo for the scene (no people names, no brands).
JSON format: {"title":"short title (max 6 words)","scenes":[{"speak":"...","caption":"...","query":"..."}]}"""
        val raw = CodeGen.ask(c, sys, user)
        var t = raw.trim()
        if (t.startsWith("```")) t = t.substringAfter('\n').substringBeforeLast("```")
        val j = try { JSONObject(t) } catch (e: Exception) { throw CodeGen.GenError("Script ka jawab JSON nahi tha, dobara try karo.") }
        val arr = j.optJSONArray("scenes") ?: JSONArray()
        val scenes = (0 until arr.length()).mapNotNull {
            val o = arr.optJSONObject(it) ?: return@mapNotNull null
            val sp = o.optString("speak").trim()
            if (sp.isBlank()) null else { val im = o.optString("image").trim(); Scene(sp, o.optString("caption").trim().ifBlank { sp }, o.optString("query").trim().ifBlank { im.take(60).ifBlank { topic } }, im) }
        }
        if (scenes.isEmpty()) throw CodeGen.GenError("Script khali aayi, dobara try karo.")
        return Plan(j.optString("title", topic).take(60).ifBlank { topic.take(40) }, scenes, j.optString("character").trim(), style.lowercase())
    }

    // ------------------------------------------------------------------ AI IMAGES
    private fun fillGaps(l: List<Bitmap?>): List<Bitmap?> {
        if (l.all { it == null }) return l
        return l.mapIndexed { i, b -> b ?: ((i - 1 downTo 0).firstNotNullOfOrNull { l[it] } ?: l.firstNotNullOf { it }) }
    }

    private fun decodeBmp(b0: ByteArray): Bitmap? {
        val bm = BitmapFactory.decodeByteArray(b0, 0, b0.size) ?: return null
        val m = max(bm.width, bm.height)
        return if (m > 1400) { val k = 1400f / m; Bitmap.createScaledBitmap(bm, (bm.width * k).toInt(), (bm.height * k).toInt(), true).also { if (it !== bm) bm.recycle() } } else bm
    }

    private fun buildPrompt(ch: String, s: Scene, sad: Boolean = false): String {
        val base = s.img.ifBlank { s.query }
        val withCh = if (ch.isNotBlank() && !base.contains(ch.take(18), true)) "$base, $ch" else base
        return if (sad) (withCh + ". Dark moody cinematic night photograph, low-key lighting, muted desaturated colours, melancholic lonely atmosphere, soft film grain, shallow depth of field, realistic, horizontal 16:9 composition. No text, no logo, no watermark.").take(900)
        else (withCh + ". Photorealistic cinematic photograph, natural light, believable real-world details and proportions, realistic textures, shallow depth of field, sharp focus, vertical 9:16 composition. No text, no logo, no watermark.").take(900)
    }

    /** Auto: Pollinations (free, bina key) -> Gemini image (aapki key) -> Pexels photo. */
    private fun aiImage(c: Context, plan: Plan, s: Scene, seed: Int, src: String, pexels: String, used: MutableSet<Long>): Bitmap? {
        val prompt = buildPrompt(plan.character, s, plan.sad)
        val order = when (src) { "pollinations" -> listOf("p"); "gemini" -> listOf("g"); "pexels" -> listOf("x"); else -> if (!gDead && (c.getSharedPreferences("divya", 0).getString("key", "") ?: "").isNotBlank()) listOf("g", "p", "x") else listOf("p", "x") }
        for (o in order) {
            val b = try {
                when (o) { "p" -> pollinations(prompt, seed, c.getSharedPreferences("divya", 0).getString("vgModel", "flux") ?: "flux", plan.sad); "g" -> geminiImage(c, prompt, refBmp.takeIf { s !== plan.scenes.firstOrNull() }, plan.sad); else -> if (pexels.isBlank()) null else fetchPhoto(pexels, s.query, used) }
            } catch (e: Exception) { imgErr = "$o: ${e.message}"; Log.w(TAG, "image $o: ${e.message}"); null }
            if (b != null) return b
        }
        return null
    }

    /** SPEED: video 576x1024 par encode hoti hai, isliye image bhi utni hi maango (720x1280 bekaar mein slow thi).
     *  Model "turbo" = bahut tez (2-5 sec); "flux" = behtar quality par slow. Pref "vgModel" se badlo. */
    private fun pollinations(prompt: String, seed: Int, model: String = "flux", wide: Boolean = false): Bitmap? {
        for (attempt in 0..2) {
            val url = "https://image.pollinations.ai/prompt/" + java.net.URLEncoder.encode(prompt, "UTF-8").replace("+", "%20") +
                "?width=${if (wide) 1024 else IW}&height=${if (wide) 576 else IH}&model=$model&nologo=true&enhance=false&seed=${seed + attempt}"
            val bytes = imgHttp.newCall(Request.Builder().url(url).header("User-Agent", "Mozilla/5.0 DivyaAI").build()).execute().use { r ->
                if (!r.isSuccessful) { imgErr = "pollinations ${r.code}"; if (r.code == 429 || r.code >= 500) try { Thread.sleep(2500L * (attempt + 1)) } catch (_: InterruptedException) {}; null } else r.body?.bytes()
            }
            if (bytes != null && bytes.size > 5000) decodeBmp(bytes)?.let { bm ->
                // free server kabhi neeche kone mein "pollinations.ai" likh deta hai: neeche ka 6% kaat do
                return try { Bitmap.createBitmap(bm, 0, 0, bm.width, (bm.height * 0.94f).toInt()) } catch (_: Exception) { bm }
            }
        }
        return null
    }

    private fun geminiImage(c: Context, prompt: String, ref: Bitmap? = null, wide: Boolean = false): Bitmap? {
        val pr = c.getSharedPreferences("divya", 0)
        val key = pr.getString("key", "") ?: ""; if (key.isBlank()) return null
        val model = pr.getString("imgModel", "gemini-2.5-flash-image") ?: "gemini-2.5-flash-image"
        val parts0 = JSONArray()
        if (ref != null && !ref.isRecycled) {
            val bo = java.io.ByteArrayOutputStream()
            Bitmap.createScaledBitmap(ref, ref.width * 640 / ref.height, 640, true).compress(Bitmap.CompressFormat.JPEG, 85, bo)
            parts0.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP))))
            parts0.put(JSONObject().put("text", "Keep EXACTLY the same character(s), face, fur/skin, clothes and art style as the reference image, but make a NEW different shot: $prompt"))
        } else parts0.put(JSONObject().put("text", prompt))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts0)))
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("IMAGE")).put("imageConfig", JSONObject().put("aspectRatio", if (wide) "16:9" else "9:16")))
            .toString()
        val req = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").header("x-goog-api-key", key)
            .post(body.toRequestBody("application/json".toMediaType())).build()
        val txt = imgHttp.newCall(req).execute().use { r -> if (!r.isSuccessful) { imgErr = "gemini ${r.code}"; if (r.code == 403 || r.code == 429 || r.code == 404) gDead = true; null } else r.body?.string() } ?: return null
        val parts = JSONObject(txt).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return null
        for (i in 0 until parts.length()) {
            val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data")
            if (!d.isNullOrBlank()) return decodeBmp(android.util.Base64.decode(d, android.util.Base64.DEFAULT))
        }
        return null
    }

    // ------------------------------------------------------------------ PHOTOS (Pexels, optional)
    private fun fetchPhoto(key: String, q: String, used: MutableSet<Long>): Bitmap? = try {
        val url = "https://api.pexels.com/v1/search?query=" + java.net.URLEncoder.encode(q, "UTF-8") + "&orientation=portrait&size=medium&per_page=8"
        val txt = http.newCall(Request.Builder().url(url).header("Authorization", key).build()).execute().use { r -> if (!r.isSuccessful) null else r.body?.string() }
        val photos = JSONObject(txt ?: "{}").optJSONArray("photos") ?: JSONArray()
        var pick: JSONObject? = null
        for (i in 0 until photos.length()) { val p = photos.getJSONObject(i); if (used.add(p.optLong("id"))) { pick = p; break } }
        val link = pick?.optJSONObject("src")?.optString("portrait")
        if (link.isNullOrBlank()) null else {
            val bytes = http.newCall(Request.Builder().url(link).build()).execute().use { r -> if (r.isSuccessful) r.body?.bytes() else null }
            bytes?.let { b0 -> val o = BitmapFactory.Options().apply { inSampleSize = 1 }; val bm = BitmapFactory.decodeByteArray(b0, 0, b0.size, o)
                if (bm != null && bm.height > 1100) Bitmap.createScaledBitmap(bm, bm.width * 1100 / bm.height, 1100, true).also { if (it !== bm) bm.recycle() } else bm }
        }
    } catch (e: Exception) { Log.w(TAG, "pexels: ${e.message}"); null }

    // ------------------------------------------------------------------ REAL VIDEO CLIPS (Pexels Videos, free key)
    /** Pexels se asli stock video clip (mp4) download karta hai. sad = landscape clip (photo band ke liye), warna portrait. */
    private fun fetchClip(c: Context, key: String, q: String, idx: Int, wide: Boolean, used: MutableSet<Long>): File? {
        val ori = if (wide) "landscape" else "portrait"
        val tries = listOf(q, q.trim().split(" ").take(2).joinToString(" ")).filter { it.isNotBlank() }.distinct()
        for (qq in tries) {
            val url = "https://api.pexels.com/videos/search?query=" + java.net.URLEncoder.encode(qq, "UTF-8") + "&orientation=$ori&per_page=15"
            val txt = imgHttp.newCall(Request.Builder().url(url).header("Authorization", key).build()).execute().use { r ->
                if (!r.isSuccessful) { imgErr = "pexels video ${r.code}"; null } else r.body?.string()
            } ?: continue
            val vids = JSONObject(txt).optJSONArray("videos") ?: continue
            for (i in 0 until vids.length()) {
                val v = vids.getJSONObject(i)
                if (v.optInt("duration") < 6) continue
                if (!used.add(v.optLong("id"))) continue
                val files = v.optJSONArray("video_files") ?: continue
                var best: JSONObject? = null; var bestD = Int.MAX_VALUE
                for (k in 0 until files.length()) {
                    val f = files.getJSONObject(k)
                    if (f.optString("file_type") != "video/mp4") continue
                    val lg = max(f.optInt("width"), f.optInt("height"))
                    if (lg < 900) continue
                    val d = Math.abs(lg - 1280)
                    if (d < bestD) { bestD = d; best = f }
                }
                val link = best?.optString("link").orEmpty()
                if (link.isBlank()) continue
                val out = File(c.cacheDir, "vg_clip_$idx.mp4"); out.delete()
                val ok = imgHttp.newCall(Request.Builder().url(link).build()).execute().use { r ->
                    if (!r.isSuccessful) false else { r.body?.byteStream()?.use { ins -> out.outputStream().use { o -> ins.copyTo(o) } }; out.length() > 50_000 }
                }
                if (ok) return out else out.delete()
            }
        }
        return null
    }

    /** Ek mp4 clip ko aage ki taraf decode karta hai (MediaCodec, YUV -> Bitmap). frameAt(sec) har baar thoda aage badhta hai; clip khatam ho to loop. */
    class ClipPlayer(val file: File) {
        private val ex = MediaExtractor()
        private var codec: MediaCodec? = null
        private val info = MediaCodec.BufferInfo()
        private var eosIn = false; private var eosOut = false
        private var curPts = Long.MIN_VALUE / 2
        private var offset = 0L; private var lastRaw = 0L
        private var rot = 0
        private val ring = arrayOfNulls<Bitmap>(4); private var ri = 0
        private var cur: Bitmap? = null
        var failed = false; private set

        init {
            try {
                ex.setDataSource(file.path)
                var ti = -1
                for (i in 0 until ex.trackCount) { if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) { ti = i; break } }
                if (ti < 0) throw IllegalStateException("video track nahi mila")
                ex.selectTrack(ti)
                val f = ex.getTrackFormat(ti)
                rot = if (f.containsKey(MediaFormat.KEY_ROTATION)) f.getInteger(MediaFormat.KEY_ROTATION) else 0
                f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
                val cd = MediaCodec.createDecoderByType(f.getString(MediaFormat.KEY_MIME)!!)
                cd.configure(f, null, null, 0); cd.start(); codec = cd
            } catch (e: Throwable) { Log.w("DivyaVideoGen", "clip open: ${e.message}"); failed = true }
        }

        fun frameAt(sec: Double): Bitmap? {
            if (failed) return null
            try {
                val target = (sec * 1_000_000).toLong()
                var guard = 0
                while (curPts < target - 40_000 && guard++ < 600) {
                    if (eosOut) restart()
                    step(target)
                }
            } catch (e: Throwable) { Log.w("DivyaVideoGen", "clip decode: ${e.message}"); failed = true }
            return cur
        }

        private fun restart() {
            val cd = codec ?: return
            offset += lastRaw + 33_000
            ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            cd.flush(); cd.start()
            eosIn = false; eosOut = false
        }

        private fun step(target: Long) {
            val cd = codec ?: return
            if (!eosIn) {
                val ii = cd.dequeueInputBuffer(5_000)
                if (ii >= 0) {
                    val buf = cd.getInputBuffer(ii)!!
                    val n = ex.readSampleData(buf, 0)
                    if (n < 0) { cd.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); eosIn = true }
                    else { cd.queueInputBuffer(ii, 0, n, ex.sampleTime, 0); ex.advance() }
                }
            }
            val oi = cd.dequeueOutputBuffer(info, 5_000)
            if (oi >= 0) {
                val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                if (info.size > 0) {
                    lastRaw = info.presentationTimeUs
                    val pts = info.presentationTimeUs + offset
                    if (pts >= target - 40_000) {       // sirf zaroorat wale frame ko Bitmap banao, baaki skip
                        val img = cd.getOutputImage(oi)
                        if (img != null) { cur = toBitmap(img); img.close(); curPts = pts }
                    }
                }
                cd.releaseOutputBuffer(oi, false)
                if (eos) eosOut = true
            }
        }

        private fun toBitmap(img: Image): Bitmap {
            val crop = img.cropRect; val w = crop.width(); val h = crop.height()
            val yP = img.planes[0]; val uP = img.planes[1]; val vP = img.planes[2]
            val yb = yP.buffer; val ub = uP.buffer; val vb = vP.buffer
            val ys = yP.rowStride; val yps = yP.pixelStride; val us = uP.rowStride; val ups = uP.pixelStride; val vs = vP.rowStride; val vps = vP.pixelStride
            val px = IntArray(w * h)
            for (j in 0 until h) {
                val yo = (crop.top + j) * ys; val uo = ((crop.top + j) shr 1) * us; val vo = ((crop.top + j) shr 1) * vs
                for (i in 0 until w) {
                    val x = crop.left + i
                    val y = ((yb.get(yo + x * yps).toInt() and 0xFF) - 16).coerceAtLeast(0) * 298
                    val u = (ub.get(uo + (x shr 1) * ups).toInt() and 0xFF) - 128
                    val v = (vb.get(vo + (x shr 1) * vps).toInt() and 0xFF) - 128
                    val r = ((y + 409 * v + 128) shr 8).coerceIn(0, 255)
                    val g = ((y - 100 * u - 208 * v + 128) shr 8).coerceIn(0, 255)
                    val b = ((y + 516 * u + 128) shr 8).coerceIn(0, 255)
                    px[j * w + i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                }
            }
            var bm = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
            if (rot != 0) { val m = Matrix().apply { postRotate(rot.toFloat()) }; bm = Bitmap.createBitmap(bm, 0, 0, w, h, m, true) }
            ring[ri] = bm; ri = (ri + 1) % ring.size      // purane bitmaps ring mein, hardware canvas ko puri tarah draw karne ka time mile
            return bm
        }

        fun release() {
            try { codec?.stop() } catch (_: Throwable) {}
            try { codec?.release() } catch (_: Throwable) {}
            try { ex.release() } catch (_: Throwable) {}
            codec = null
        }
    }

    // ------------------------------------------------------------------ TTS
    // ---- Natural "viral" awaaz: Gemini TTS (phone ki robot awaaz se bahut behtar). Fail ho to phone TTS chalti hai. ----
    private val ttsHttp = OkHttpClient.Builder().connectTimeout(6, TimeUnit.SECONDS).readTimeout(14, TimeUnit.SECONDS).build()

    /** style -> (awaaz ka naam, bolne ka andaaz). Pref "vgVoiceName" se awaaz badal sakte ho (Puck, Fenrir, Charon, Kore, Aoede, Leda, Zephyr, Algenib, Orus). */
    private fun voiceFor(style: String, en: Boolean): Pair<String, String> {
        val s = style.lowercase()
        val lang = if (en) "English" else "Hindi"
        return when {
            s.contains("funny") || s.contains("meme") || s.contains("roast") ->
                "Puck" to "Say in $lang like a fun, energetic viral Reels creator: fast, playful, with comic timing, a laugh in the voice and punchy emphasis"
            s.contains("attitude") || s.contains("badmash") || s.contains("swag") ->
                "Algenib" to "Say in $lang in a deep, confident, bold swag voice: slow, heavy, punchy, with short dramatic pauses, like a movie villain-hero"
            s.contains("sad") || s.contains("shayari") || s.contains("status") ->
                "Aoede" to "Say in $lang softly and emotionally, slow and heavy-hearted, with gentle pauses"
            s.contains("motiv") ->
                "Fenrir" to "Say in $lang like a powerful motivational speaker: intense, rising energy, strong emphasis on key words"
            else ->
                "Fenrir" to "Say in $lang like a gripping storyteller who hooks the listener: excited, dramatic, curious, a pause before big reveals, crisp and clear"
        }
    }

    private fun geminiVoice(c: Context, text: String, voice: String, direction: String): Pcm? {
        val pr = c.getSharedPreferences("divya", 0)
        val key = pr.getString("key", "")?.trim().orEmpty(); if (key.isBlank()) return null
        val model = pr.getString("ttsModel", "gemini-2.5-flash-preview-tts") ?: "gemini-2.5-flash-preview-tts"
        val vname = pr.getString("vgVoiceName", "")?.trim().orEmpty().ifBlank { voice }
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "$direction:\n$text")))))
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", vname)))))
            .toString()
        for (attempt in 0..1) {
            try {
                val req = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").header("x-goog-api-key", key)
                    .post(body.toRequestBody("application/json".toMediaType())).build()
                val txt = ttsHttp.newCall(req).execute().use { r -> if (!r.isSuccessful) { imgErr = "tts ${r.code}"; null } else r.body?.string() } ?: continue
                val parts = JSONObject(txt).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: continue
                for (i in 0 until parts.length()) {
                    val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data")
                    if (!d.isNullOrBlank()) {
                        val raw = android.util.Base64.decode(d, android.util.Base64.DEFAULT)
                        val n = raw.size / 2
                        val sh = ShortArray(n) { k -> ((raw[2 * k].toInt() and 0xFF) or (raw[2 * k + 1].toInt() shl 8)).toShort() }
                        return polish(Pcm(24000, sh))
                    }
                }
            } catch (e: Exception) { Log.w(TAG, "gemini tts: ${e.message}") }
        }
        return null
    }

    /** Shuru/ant ki khali awaaz hatao aur volume barabar (loud + clear) karo. */
    private fun polish(p: Pcm): Pcm {
        val s = p.s; if (s.isEmpty()) return p
        val th = 600
        var a = 0; while (a < s.size && Math.abs(s[a].toInt()) < th) a++
        var b = s.size - 1; while (b > a && Math.abs(s[b].toInt()) < th) b--
        val keep = (p.sr * 0.05).toInt()
        val from = (a - keep).coerceAtLeast(0); val to = (b + keep).coerceAtMost(s.size - 1)
        if (to <= from) return p
        var peak = 1; for (i in from..to) peak = max(peak, Math.abs(s[i].toInt()))
        val g = (30000.0 / peak).coerceIn(0.5, 4.0)
        return Pcm(p.sr, ShortArray(to - from + 1) { i -> (s[from + i] * g).toInt().coerceIn(-32768, 32767).toShort() })
    }

    /** Saare scenes ki awaaz ek saath (parallel). Ek bhi fail ho to null -> poori video phone ki TTS se (awaaz mix na ho). */
    private fun synth(c: Context, scenes: List<Scene>, en: Boolean, style: String): List<Pcm> {
        if (c.getSharedPreferences("divya", 0).getBoolean("vgPhoneVoice", false)) return synthPhone(c, scenes, en)
        val (voice, dir) = voiceFor(style, en)
        val pool = Executors.newFixedThreadPool(min(6, scenes.size).coerceAtLeast(1))
        try {
            val fs = scenes.map { sc -> pool.submit<Pcm?> { geminiVoice(c, sc.speak, voice, dir) } }
            val out = fs.map { try { it.get(25, TimeUnit.SECONDS) } catch (_: Exception) { null } }
            if (out.all { it != null }) return out.map { it!! }
        } finally { pool.shutdownNow() }
        Log.w(TAG, "Gemini awaaz nahi bani (${imgErr}), phone TTS use ho rahi hai")
        return synthPhone(c, scenes, en)
    }

    private fun synthPhone(c: Context, scenes: List<Scene>, en: Boolean): List<Pcm> {
        val ready = CountDownLatch(1); var ok = false
        val tts = TextToSpeech(c.applicationContext) { st -> ok = st == TextToSpeech.SUCCESS; ready.countDown() }
        if (!ready.await(10, TimeUnit.SECONDS) || !ok) { tts.shutdown(); throw CodeGen.GenError("Phone ka TTS (Google Text-to-speech) start nahi hua. Settings > Text-to-speech engine check karo.") }
        try {
            val want = if (en) Locale("en", "IN") else Locale("hi", "IN")
            var r = tts.setLanguage(want)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                r = tts.setLanguage(if (en) Locale.US else Locale.ENGLISH)
                if (!en) Log.w(TAG, "Hindi TTS voice nahi mili, English fallback")
            }
            tts.setSpeechRate(1.12f)
            val files = scenes.indices.map { File(c.cacheDir, "vg_tts_$it.wav").also { f -> f.delete() } }
            val latches = scenes.indices.map { CountDownLatch(1) }
            val errs = BooleanArray(scenes.size)
            fun idx(u: String?) = u?.removePrefix("vg")?.toIntOrNull()?.takeIf { it in scenes.indices }
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(u: String?) {}
                override fun onDone(u: String?) { idx(u)?.let { latches[it].countDown() } }
                @Deprecated("old") override fun onError(u: String?) { idx(u)?.let { errs[it] = true; latches[it].countDown() } }
                override fun onError(u: String?, code: Int) { idx(u)?.let { errs[it] = true; latches[it].countDown() } }
            })
            scenes.forEachIndexed { i, s ->
                if (tts.synthesizeToFile(s.speak, Bundle(), files[i], "vg$i") != TextToSpeech.SUCCESS) throw CodeGen.GenError("Scene ${i + 1} ki awaaz queue nahi hui (TTS error).")
            }
            val out = ArrayList<Pcm>()
            scenes.indices.forEach { i ->
                if (!latches[i].await(40, TimeUnit.SECONDS) || errs[i] || !files[i].exists() || files[i].length() < 100)
                    throw CodeGen.GenError("Scene ${i + 1} ki awaaz nahi ban payi (TTS error).")
                out.add(readWav(files[i])); files[i].delete()
            }
            return out
        } finally { tts.shutdown() }
    }

    private fun readWav(f: File): Pcm {
        val b = f.readBytes(); val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        var p = 12; var sr = 22050; var ch = 1; var bits = 16; var off = -1; var len = 0
        while (p + 8 <= b.size) {
            val id = String(b, p, 4, Charsets.US_ASCII); val l = bb.getInt(p + 4)
            if (id == "fmt ") { ch = bb.getShort(p + 10).toInt(); sr = bb.getInt(p + 12); bits = bb.getShort(p + 22).toInt() }
            if (id == "data") { off = p + 8; len = if (l <= 0 || off + l > b.size) b.size - off else l; break }
            if (l < 0) break
            p += 8 + l + (l and 1)
        }
        if (off < 0 || bits != 16 || ch < 1) throw CodeGen.GenError("TTS ki audio file ka format samajh nahi aaya.")
        val n = len / 2 / ch
        val s = ShortArray(n) { i -> var acc = 0; for (k in 0 until ch) acc += bb.getShort(off + (i * ch + k) * 2); (acc / ch).toShort() }
        return Pcm(sr, s)
    }

    private fun resample(s: ShortArray, from: Int, to: Int): ShortArray {
        if (from == to || s.isEmpty()) return s
        val n = (s.size.toLong() * to / from).toInt()
        return ShortArray(n) { i -> val pos = i.toDouble() * from / to; val i0 = pos.toInt().coerceAtMost(s.size - 1); val i1 = (i0 + 1).coerceAtMost(s.size - 1); val fr = pos - i0; (s[i0] * (1 - fr) + s[i1] * fr).toInt().toShort() }
    }

    private fun playAudio(pcm: ShortArray, sr: Int): AudioTrack? = try {
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
        t.write(pcm, 0, pcm.size); t.play(); t
    } catch (e: Exception) { Log.w(TAG, "preview audio: ${e.message}"); null }

    /** Sad reel ke liye halka original ambient music (piano jaisa arpeggio + pad, Am-F-C-G). Copyright wala gaana nahi, sab yahin bana. */
    private fun mixSadMusic(a: ShortArray, sr: Int) {
        val prog = arrayOf(intArrayOf(57, 60, 64), intArrayOf(53, 57, 60), intArrayOf(48, 52, 55), intArrayOf(55, 59, 62))
        fun hz(m: Int) = 440.0 * Math.pow(2.0, (m - 69) / 12.0)
        val padF = Array(4) { c -> DoubleArray(3) { k -> hz(prog[c][k] - 12) } }
        val pluckF = Array(4) { c -> DoubleArray(3) { k -> hz(prog[c][k] + 12) } }
        val chordLen = sr * 4
        val twoPi = 2.0 * PI
        val n = a.size
        for (i in 0 until n) {
            val ci = (i / chordLen) % 4
            val pos = (i % chordLen).toDouble() / sr          // 0..4 sec
            val t = i.toDouble() / sr
            val e = sin(PI * pos / 4.0)                        // chord ka naram aana-jaana
            var pad = 0.0
            for (k in 0 until 3) pad += sin(twoPi * padF[ci][k] * t)
            pad = pad / 3.0 * e * 1700.0
            val step = (pos / 0.5).toInt(); val pp = pos - step * 0.5
            val pl = sin(twoPi * pluckF[ci][step % 3] * t) * Math.exp(-pp * 5.0) * min(1.0, pp * 150.0) * 2000.0
            val fade = min(1.0, t / 1.0) * min(1.0, (n - i).toDouble() / sr / 1.5)
            a[i] = (a[i] + (pad + pl) * fade).toInt().coerceIn(-32768, 32767).toShort()
        }
    }

    // ------------------------------------------------------------------ AUDIO ENCODE (AAC)
    private fun encodeAudio(pcm: ShortArray, sr: Int, out: File) {
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sr, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 64000); setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); codec.start()
        val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1; var started = false
        val info = MediaCodec.BufferInfo(); var pos = 0; var inDone = false; var outDone = false
        try {
            while (!outDone) {
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!; buf.clear(); buf.order(ByteOrder.LITTLE_ENDIAN)
                        val n = min(pcm.size - pos, buf.capacity() / 2)
                        val pts = pos * 1_000_000L / sr
                        if (n <= 0) { codec.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { for (k in 0 until n) buf.putShort(pcm[pos + k]); codec.queueInputBuffer(ii, 0, n * 2, pts, 0); pos += n }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { track = mux.addTrack(codec.outputFormat); mux.start(); started = true }
                else if (oi >= 0) {
                    val ob = codec.getOutputBuffer(oi)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && started) { ob.position(info.offset); ob.limit(info.offset + info.size); mux.writeSampleData(track, ob, info) }
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) {}; codec.release()
            try { if (started) mux.stop() } catch (_: Exception) {}; mux.release()
        }
    }

    // ------------------------------------------------------------------ VIDEO ENCODE (H.264 from Canvas)
    private fun encodeVideo(plan: Plan, bmps: List<Bitmap?>, starts: List<Double>, durs: List<Double>, speak: List<Double>,
                            totalSec: Double, out: File, clips: List<File?>, progress: (Float) -> Unit) {
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, W, H).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 9_000_000); setInteger(MediaFormat.KEY_FRAME_RATE, FPS); setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = codec.createInputSurface(); codec.start()
        val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1; var started = false; var outCount = 0L
        val info = MediaCodec.BufferInfo()
        // Encoder kabhi-kabhi frames gira deta hai (vendor rate control) -> pehle frame-counter se video chhoti ho jati thi (15s video, 18s awaaz).
        // Ab har output frame ko uske asli frame number se map karte hain, gira hua frame = purana frame hold (timeline sahi).
        val frames = Math.ceil(totalSec * FPS).toInt()
        val postUs = LongArray(frames + 1); var posted = 0
        var offsetUs = Long.MIN_VALUE; var lastRaw = -1L; var useCounter = false; var lastPts = -1L; var lastIdx = 0

        fun drain(end: Boolean) {
            while (true) {
                val oi = codec.dequeueOutputBuffer(info, if (end) 10_000 else 0)
                when {
                    oi == MediaCodec.INFO_TRY_AGAIN_LATER -> { if (!end) return }
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> { track = mux.addTrack(codec.outputFormat); mux.start(); started = true }
                    oi >= 0 -> {
                        val ob = codec.getOutputBuffer(oi)!!
                        val cfg = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                        if (!cfg && info.size > 0 && started) {
                            // Canvas surface par timestamp system clock ka aata hai -> apna frame-counter pts
                            val raw = info.presentationTimeUs
                            var pts: Long
                            if (!useCounter && posted > 0 && raw > lastRaw) {
                                if (offsetUs == Long.MIN_VALUE) offsetUs = raw - postUs[0]
                                val want = raw - offsetUs
                                var k = lastIdx
                                while (k + 1 < posted && Math.abs(postUs[k + 1] - want) <= Math.abs(postUs[k] - want)) k++
                                lastIdx = k; lastRaw = raw
                                pts = k * 1_000_000L / FPS
                            } else { useCounter = true; pts = outCount * 1_000_000L / FPS }
                            if (pts <= lastPts) pts = lastPts + 1000L
                            lastPts = pts; info.presentationTimeUs = pts; outCount++
                            ob.position(info.offset); ob.limit(info.offset + info.size); mux.writeSampleData(track, ob, info)
                        }
                        codec.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    }
                }
            }
        }

        val r = Renderer(plan, bmps, starts, durs, speak, clips)
        try {
            var lastPostNs = 0L
            for (f in 0 until frames) {
                val gap = (System.nanoTime() - lastPostNs) / 1_000_000L
                if (f > 0 && gap < 20) try { Thread.sleep(20 - gap) } catch (_: InterruptedException) {}   // frames ke beech thoda gap: timestamps saaf rehte hain
                val canvas = surface.lockHardwareCanvas()
                try { r.draw(canvas, f.toDouble() / FPS) } finally { surface.unlockCanvasAndPost(canvas) }
                lastPostNs = System.nanoTime(); postUs[f] = lastPostNs / 1000L; posted = f + 1
                drain(false)
                if (f % 15 == 0) progress(f.toFloat() / frames)
            }
            codec.signalEndOfInputStream(); drain(true)
        } finally {
            r.release()
            try { codec.stop() } catch (_: Exception) {}; codec.release(); surface.release()
            try { if (started) mux.stop() } catch (_: Exception) {}; mux.release()
        }
    }

    /** Ek frame banane wala: background (photo Ken-Burns ya neon), gradient, title, subtitles. */
    class Renderer(val plan: Plan, val bmps: List<Bitmap?>, val starts: List<Double>, val durs: List<Double>, val speak: List<Double>, val clips: List<File?> = emptyList()) {
        private val players = arrayOfNulls<ClipPlayer>(plan.scenes.size)
        /** Is scene ki asli video clip ka frame (local = scene ke andar ke seconds). Clip na ho/fail ho to null. */
        fun clipFrame(si: Int, local: Double): Bitmap? {
            val f = clips.getOrNull(si) ?: return null
            for (k in 0 until si - 1) { players[k]?.release(); players[k] = null }   // purani scenes ke decoders band (hardware decoder limit)
            val pl = players[si] ?: ClipPlayer(f).also { players[si] = it }
            return if (pl.failed) null else pl.frameAt(local)
        }
        fun release() { for (i in players.indices) { players[i]?.release(); players[i] = null } }
        val gold = 0xFFFFE81F.toInt()
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 60f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); color = Color.WHITE }
        val tpStroke = TextPaint(tp).apply { style = Paint.Style.STROKE; strokeWidth = 12f; color = Color.BLACK; strokeJoin = Paint.Join.ROUND }
        val titleP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 44f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); color = Color.BLACK }
        val wmP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 30f; typeface = Typeface.MONOSPACE; color = gold; alpha = 150 }
        val chunks: List<List<String>> = plan.scenes.map { chunk(it.caption) }
        val layouts = HashMap<String, Pair<StaticLayout, StaticLayout>>()
        val basePalette = intArrayOf(0xFF0B3D91.toInt(), 0xFF6A1B9A.toInt(), 0xFF00695C.toInt(), 0xFFB71C1C.toInt(), 0xFFEF6C00.toInt(), 0xFF283593.toInt(), 0xFF004D40.toInt(), 0xFF880E4F.toInt())
        val palette: IntArray = when {
            plan.style.contains("funny") -> intArrayOf(0xFFFF6F00.toInt(), 0xFFFFB300.toInt(), 0xFFD81B60.toInt(), 0xFF00ACC1.toInt(), 0xFF7CB342.toInt(), 0xFF8E24AA.toInt())
            plan.style.contains("attitude") || plan.style.contains("badmash") -> intArrayOf(0xFF8B0000.toInt(), 0xFF212121.toInt(), 0xFFB71C1C.toInt(), 0xFF37474F.toInt(), 0xFF4A148C.toInt(), 0xFF000000.toInt())
            else -> basePalette
        }
        val grad = LinearGradient(0f, DH * 0.5f, 0f, DH.toFloat(), 0x00000000, 0xAA000000.toInt(), Shader.TileMode.CLAMP)
        val gradTop = LinearGradient(0f, 0f, 0f, DH * 0.2f, 0x99000000.toInt(), 0x00000000, Shader.TileMode.CLAMP)
        val vig = RadialGradient(DW / 2f, DH / 2f, DH * 0.72f, 0x00000000, 0x55000000, Shader.TileMode.CLAMP)   // halka vignette: film jaisa look

        fun chunk(t: String): List<String> {
            val w = t.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            val out = ArrayList<String>(); var cur = ArrayList<String>()
            for (x in w) { cur.add(x); if (cur.size >= 3 || cur.joinToString(" ").length > 16 || x.endsWith(".") || x.endsWith("?") || x.endsWith(",")) { out.add(cur.joinToString(" ")); cur = ArrayList() } }
            if (cur.isNotEmpty()) out.add(cur.joinToString(" "))
            return out
        }

        fun draw(cv: Canvas, t: Double, ow: Float = W.toFloat(), oh: Float = H.toFloat()) {
            cv.save(); cv.scale(ow / DW, oh / DH)
            drawScene(cv, t)
            cv.restore()
        }

        fun drawScene(cv: Canvas, t: Double) {
            var si = starts.indexOfLast { it <= t }.coerceAtLeast(0)
            if (si >= plan.scenes.size) si = plan.scenes.size - 1
            val local = (t - starts[si]).coerceAtLeast(0.0); val dur = durs[si]
            val prog = (local / dur).coerceIn(0.0, 1.0).toFloat()
            // is scene ki image abhi na aayi ho to pichhli scene ki image dikhao (neon sirf tab jab koi bhi image nahi)
            val clipBmp = clipFrame(si, local)
            val bmp = clipBmp ?: (si downTo 0).firstNotNullOfOrNull { k -> bmps[k]?.takeIf { !it.isRecycled } }
            val calm = clipBmp != null
            if (plan.sad) { drawSad(cv, t, si, local, dur, prog, bmp, calm); return }
            if (bmp != null) drawPhoto(cv, bmp, prog, si, calm = calm) else drawNeon(cv, t.toFloat(), si)
            if (bmp != null && si + 1 < bmps.size && dur - local < 0.5) { // crossfade agle scene ki image mein
                val nb = clipFrame(si + 1, 0.0) ?: bmps[si + 1]
                if (nb != null && nb !== bmp) { p.alpha = (255 * (1 - (dur - local) / 0.5)).toInt().coerceIn(0, 255); drawPhoto(cv, nb, 0f, si + 1, calm = clips.getOrNull(si + 1) != null); p.alpha = 255 }
            }
            if (bmp != null) { p.shader = vig; cv.drawRect(0f, 0f, DW.toFloat(), DH.toFloat(), p); p.shader = null }
            p.shader = grad; cv.drawRect(0f, DH * 0.5f, DW.toFloat(), DH.toFloat(), p)
            p.shader = gradTop; cv.drawRect(0f, 0f, DW.toFloat(), DH * 0.2f, p); p.shader = null

            cv.drawText("DIVYA AI", 36f, 70f, wmP)
            if (t < 2.8 && si == 0 && bmp == null) { // title pill (sirf neon background par)
                val a = (min(1.0, (2.8 - t) / 0.4)).toFloat()
                val tl = StaticLayout.Builder.obtain(plan.title, 0, plan.title.length, titleP, (DW - 160).toInt()).setAlignment(Layout.Alignment.ALIGN_CENTER).setMaxLines(2).build()
                p.color = gold; p.alpha = (255 * a).toInt()
                cv.drawRoundRect(40f, 150f, DW - 40f, 150f + tl.height + 40f, 28f, 28f, p)
                cv.save(); cv.translate(80f, 170f); titleP.alpha = (255 * a).toInt(); tl.draw(cv); cv.restore(); titleP.alpha = 255
                p.alpha = 255
            }
            // subtitles
            val ch = chunks[si]
            if (ch.isNotEmpty()) {
                val sp = speak[si].coerceAtLeast(0.5); val st = (local - 0.12).coerceAtLeast(0.0)
                val frac = (st / sp).coerceIn(0.0, 0.9999)
                val totalChars = ch.sumOf { it.length + 1 }.toDouble(); var acc = 0.0; var idx = ch.size - 1; var cStart = 0.0
                for (i in ch.indices) { val s0 = acc / totalChars; acc += (ch[i].length + 1); if (frac < acc / totalChars) { idx = i; cStart = s0 * sp; break } }
                val since = (st - cStart).toFloat().coerceAtLeast(0f)
                val pop = if (since < 0.14f) 0.88f + 0.12f * (since / 0.14f) else 1f
                val text = ch[idx]
                val (strokeL, fillL) = layouts.getOrPut(text) {
                    Pair(StaticLayout.Builder.obtain(text, 0, text.length, tpStroke, (DW - 120).toInt()).setAlignment(Layout.Alignment.ALIGN_CENTER).build(),
                        StaticLayout.Builder.obtain(text, 0, text.length, tp, (DW - 120).toInt()).setAlignment(Layout.Alignment.ALIGN_CENTER).build())
                }
                cv.save(); cv.translate(60f, DH * 0.72f); cv.scale(pop, pop, (DW - 120) / 2f, fillL.height / 2f)
                strokeL.draw(cv); fillL.draw(cv); cv.restore()
            }
            // scene fade-in
            if (local < 0.25 && si > 0 && bmp == null) { p.color = Color.BLACK; p.alpha = (255 * (1 - local / 0.25)).toInt(); cv.drawRect(0f, 0f, DW.toFloat(), DH.toFloat(), p); p.alpha = 255 }
            if (t < 0.3) { p.color = Color.BLACK; p.alpha = (255 * (1 - t / 0.3)).toInt(); cv.drawRect(0f, 0f, DW.toFloat(), DH.toFloat(), p); p.alpha = 255 }
        }

        val sadP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 46f; typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL); color = Color.WHITE }
        val sadLayouts = HashMap<String, StaticLayout>()
        val bandTop = 440; val bandBot = 860

        /** Sad reel layout: kaala canvas, beech mein dark photo band, upar serif text (fade in/out), neeche chhota naam. */
        fun drawSad(cv: Canvas, t: Double, si: Int, local: Double, dur: Double, prog: Float, bmp: Bitmap?, calm: Boolean = false) {
            cv.drawColor(Color.BLACK)
            val dst = Rect(0, bandTop, DW.toInt(), bandBot)
            if (bmp != null) {
                drawPhoto(cv, bmp, prog, si, dst, calm)
                val rem = dur - local
                if (si + 1 < bmps.size && rem < 0.8) {
                    val nb = clipFrame(si + 1, 0.0) ?: bmps[si + 1]
                    if (nb != null && nb !== bmp) { p.alpha = (255 * (1 - rem / 0.8)).toInt().coerceIn(0, 255); drawPhoto(cv, nb, 0f, si + 1, dst, clips.getOrNull(si + 1) != null); p.alpha = 255 }
                }
                p.color = Color.BLACK; p.alpha = 70; cv.drawRect(dst, p); p.alpha = 255     // thoda aur dark
                p.shader = RadialGradient(DW / 2f, (bandTop + bandBot) / 2f, DW * 0.75f, 0x00000000, 0x99000000.toInt(), Shader.TileMode.CLAMP)
                cv.drawRect(dst, p); p.shader = null
            }
            cv.drawText("DIVYA AI", 36f, bandBot + 60f, wmP)
            val text = plan.scenes[si].caption
            val lay = sadLayouts.getOrPut(text) { StaticLayout.Builder.obtain(text, 0, text.length, sadP, (DW - 100).toInt()).setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0f, 1.1f).build() }
            val a = (min(1.0, local / 0.7) * min(1.0, (dur - local) / 0.5)).coerceIn(0.0, 1.0)
            sadP.alpha = (255 * a).toInt()
            cv.save(); cv.translate(50f, bandTop - 40f - lay.height); lay.draw(cv); cv.restore()
            sadP.alpha = 255
            if (t < 0.8) { p.color = Color.BLACK; p.alpha = (255 * (1 - t / 0.8)).toInt().coerceIn(0, 255); cv.drawRect(0f, 0f, DW, DH, p); p.alpha = 255 }
        }

        fun drawPhoto(cv: Canvas, b: Bitmap, prog: Float, si: Int, dst: Rect = Rect(0, 0, DW.toInt(), DH.toInt()), calm: Boolean = false) {
            val target = dst.width().toFloat() / dst.height()
            var cw = b.width.toFloat(); var chh = cw / target
            if (chh > b.height) { chh = b.height.toFloat(); cw = chh * target }
            val e = prog * prog * (3f - 2f * prog)                 // ease in-out
            val mv = si % 4                                        // har scene mein alag camera move: push-in, pan, pull-out, tilt
            val zoom = if (calm) 1.0f + 0.05f * e else when (mv) { 0 -> 1.04f + 0.20f * e; 1 -> 1.14f; 2 -> 1.24f - 0.20f * e; else -> 1.14f }
            val vw = cw / zoom; val vh = chh / zoom
            val maxX = (b.width - vw) / 2f; val maxY = (b.height - vh) / 2f
            val px = if (calm) 0f else when (mv) { 1 -> maxX * (1f - 2f * e); 3 -> maxX * (2f * e - 1f); else -> 0f }
            val py = if (calm) 0f else when (mv) { 3 -> maxY * (0.6f - 1.2f * e); 0 -> -maxY * 0.15f * e; else -> 0f }
            val t = prog * 7f + si                                 // halka handheld hilna: camera asli lagta hai
            val cx = b.width / 2f + px + sin(t * 2.3f) * vw * 0.004f
            val cy = b.height / 2f + py + cos(t * 1.9f) * vh * 0.004f
            val src = Rect((cx - vw / 2).toInt().coerceIn(0, b.width - 1), (cy - vh / 2).toInt().coerceIn(0, b.height - 1),
                (cx + vw / 2).toInt().coerceIn(1, b.width), (cy + vh / 2).toInt().coerceIn(1, b.height))
            cv.drawBitmap(b, src, dst, p)
        }

        fun drawNeon(cv: Canvas, t: Float, si: Int) {
            val base = palette[si % palette.size]
            p.shader = LinearGradient(0f, 0f, 0f, DH.toFloat(), 0xFF05070D.toInt(), base, Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, DW.toFloat(), DH.toFloat(), p); p.shader = null
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = Color.WHITE; p.alpha = 22
            var gy = (t * 40f) % 80f
            while (gy < DH) { cv.drawLine(0f, gy, DW.toFloat(), gy, p); gy += 80f }
            var gx = 0f; while (gx < DW) { cv.drawLine(gx, 0f, gx, DH.toFloat(), p); gx += 80f }
            val cx = DW / 2f; val cy = DH * 0.34f
            for (k in 0 until 4) {
                val r = 120f + k * 62f + 8f * sin(t * 1.6f + k)
                p.color = gold; p.alpha = 200 - k * 40; p.strokeWidth = 10f - k * 2f
                cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), (t * (50f + k * 25f) * (if (k % 2 == 0) 1 else -1)) % 360f, 95f + k * 20f, false, p)
            }
            p.style = Paint.Style.FILL; p.alpha = 255
            for (k in 0 until 14) {
                val x = ((k * 97 + si * 31) % DW).toFloat(); val y = (DH - ((t * (60f + k * 9f) + k * 150f) % DH))
                p.color = Color.WHITE; p.alpha = 70; cv.drawCircle(x, y, 3f + (k % 3), p)
            }
            p.alpha = 255
        }
    }

    // ------------------------------------------------------------------ MERGE
    private fun merge(video: File, audio: File, out: File) {
        val ev = MediaExtractor().apply { setDataSource(video.path) }
        val ea = MediaExtractor().apply { setDataSource(audio.path) }
        val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        try {
            ev.selectTrack(0); ea.selectTrack(0)
            val tv = mux.addTrack(ev.getTrackFormat(0)); val ta = mux.addTrack(ea.getTrackFormat(0))
            mux.start()
            val buf = ByteBuffer.allocate(1 shl 20); val info = MediaCodec.BufferInfo()
            var vDone = false; var aDone = false
            while (!vDone || !aDone) {
                val useV = !vDone && (aDone || ev.sampleTime <= ea.sampleTime)
                val ex = if (useV) ev else ea; val tr = if (useV) tv else ta
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) { if (useV) vDone = true else aDone = true; continue }
                info.set(0, n, ex.sampleTime, if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                mux.writeSampleData(tr, buf, info); ex.advance()
            }
            mux.stop()
        } finally { ev.release(); ea.release(); try { mux.release() } catch (_: Exception) {} }
    }

    // ------------------------------------------------------------------ SAVE / DELETE
    /** Android 10+ par Gallery (Movies/DivyaVideos) mein bhi dikhe; purane Android par sirf app folder. */
    fun saveToGallery(c: Context, f: File): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, f.name); put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/DivyaVideos"); put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = c.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: return false
        c.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } } ?: return false
        val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
        c.contentResolver.update(uri, done, null, null)
        return true
    }

    fun delete(f: File) { f.delete(); File(f.path + ".txt").delete() }
}
