package com.divya.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray

class DivyaService : AccessibilityService() {
    companion object { var instance: DivyaService? = null }
    override fun onServiceConnected() {
        instance = this
        if (getSharedPreferences("divya", 0).getBoolean("float", false)) com.divya.ai.glow.FloatingAvatar.show(this)
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        com.divya.ai.glow.GlowOverlay.hide(); com.divya.ai.glow.FloatingAvatar.hide(); instance = null; super.onDestroy()
    }

    private fun nap(ms: Long) { try { Thread.sleep(ms) } catch (_: InterruptedException) {} }

    fun global(a: String): Boolean = when (a) {
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        "lock" -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        "screenshot" -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        else -> false
    }

    fun curPkg(): String = rootInActiveWindow?.packageName?.toString() ?: ""

    /** App khulne tak ruko (fixed delay nahi, jaise hi khule turant aage badho). */
    fun waitOpen(pkg: String, timeoutMs: Long = 2500) {
        val end = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < end) {
            if (curPkg() == pkg) { nap(250); return }
            nap(50)
        }
    }

    /** Screen par text aane tak ruko, aate hi turant mil jaye. */
    private fun waitNode(t: String, timeoutMs: Long): AccessibilityNodeInfo? {
        val end = SystemClock.uptimeMillis() + timeoutMs
        while (true) {
            rootInActiveWindow?.findAccessibilityNodeInfosByText(t)?.firstOrNull()?.let { return it }
            if (SystemClock.uptimeMillis() >= end) return null
            nap(60)
        }
    }

    fun tapAt(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 40)).build(), null, null)
    }

    fun tapText(t: String, waitMs: Long = 2500): Boolean {
        val n = waitNode(t, waitMs) ?: return false
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect(); n.getBoundsInScreen(r)
        return tapAt(r.centerX().toFloat(), r.centerY().toFloat())
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i))?.let { return it }
        return null
    }

    fun typeText(t: String): Boolean {
        val end = SystemClock.uptimeMillis() + 2000
        var f: AccessibilityNodeInfo?
        while (true) {
            val root = rootInActiveWindow
            f = root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root)
            if (f != null || SystemClock.uptimeMillis() >= end) break
            nap(60)
        }
        val node = f ?: return false
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    /** Enter / Search / Send dabana. */
    fun submit(): Boolean {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f != null && Build.VERSION.SDK_INT >= 30 &&
            f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return true
        return tapText("Search", 600) || tapText("Send", 600)
    }

    fun scroll(dir: String): Boolean {
        fun find(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (n == null) return null
            if (n.isScrollable) return n
            for (i in 0 until n.childCount) find(n.getChild(i))?.let { return it }
            return null
        }
        val s = find(rootInActiveWindow) ?: return false
        return s.performAction(if (dir == "up") AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    /** Screen par kya dikh raha hai (Divya ko "aankhein"). */
    fun readScreen(max: Int = 1800): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > max || !n.isVisibleToUser) return
            val label = (n.text ?: n.contentDescription ?: "").toString().trim().replace("\n", " ")
            if (label.isNotEmpty() || n.isEditable) {
                val tag = if (n.isEditable) "[input] " else if (n.isClickable) "[btn] " else ""
                sb.append(tag).append(label.take(60)).append(" | ")
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return "app=" + curPkg() + " :: " + sb.toString().take(max)
    }

    private fun findFirstVideo(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        val d = n.contentDescription?.toString() ?: ""
        val bad = d.contains("sponsor", true) || d.contains("short", true) || d.contains("playlist", true)
        if (!bad && n.isVisibleToUser && (d.contains("play video", true) ||
                (d.length > 25 && d.contains(" - ") && (d.contains("minute", true) || d.contains("second", true))))) return n
        for (i in 0 until n.childCount) findFirstVideo(n.getChild(i))?.let { return it }
        return null
    }

    private val ytHttp by lazy { okhttp3.OkHttpClient.Builder().callTimeout(8, java.util.concurrent.TimeUnit.SECONDS).build() }

    /** YouTube search page se pehle video ka ID nikalo (screen tap karne se zyada bharosemand aur tez). */
    private fun youtubeFirstVideoId(q: String): String? = try {
        val req = okhttp3.Request.Builder()
            .url("https://www.youtube.com/results?search_query=" + android.net.Uri.encode(q) + "&sp=EgIQAQ%3D%3D")
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")
            .header("Accept-Language", "en-IN,en;q=0.9,hi;q=0.8")
            .header("Cookie", "CONSENT=YES+1; SOCS=CAI")
            .build()
        ytHttp.newCall(req).execute().use { r ->
            val html = r.body?.string().orEmpty()
            Regex("\"videoRenderer\":\\{\"videoId\":\"([A-Za-z0-9_-]{11})\"").find(html)?.groupValues?.get(1)
        }
    } catch (e: Exception) { null }

    /** YouTube par song search karke pehla result seedha play karta hai. */
    fun playOnYoutube(q: String): String {
        val vid = youtubeFirstVideoId(q)
        if (vid != null) {
            val yt0 = "com.google.android.youtube"
            val w = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com/watch?v=$vid")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (packageManager.getLaunchIntentForPackage(yt0) != null) w.setPackage(yt0)
            try { startActivity(w); return "done: playing '$q' on YouTube" } catch (_: Exception) {}
        }
        // Fallback: search screen kholke pehla result tap karo
        val uri = android.net.Uri.parse("https://www.youtube.com/results?search_query=" + android.net.Uri.encode(q))
        val yt = "com.google.android.youtube"
        val i = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (packageManager.getLaunchIntentForPackage(yt) != null) i.setPackage(yt)
        try { startActivity(i) } catch (e: Exception) { return "failed: YouTube nahi khula" }
        waitOpen(yt, 4000)
        val end = SystemClock.uptimeMillis() + 7000
        while (SystemClock.uptimeMillis() < end) {
            val v = findFirstVideo(rootInActiveWindow)
            if (v != null) {
                var cl: AccessibilityNodeInfo? = v
                while (cl != null && !cl.isClickable) cl = cl.parent
                if (cl != null && cl.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "done: playing first result for $q"
                val r = Rect(); v.getBoundsInScreen(r)
                if (tapAt(r.centerX().toFloat(), r.centerY().toFloat())) return "done: playing first result for $q"
            }
            nap(150)
        }
        val dm = resources.displayMetrics
        tapAt(dm.widthPixels / 2f, dm.heightPixels * 0.32f)
        return "done: tapped first result (fallback) for $q"
    }

    /** Poora kaam ek hi call mein: open_app, tap, type, submit, scroll_down/up, wait, home/back... */
    fun runSteps(steps: JSONArray): String {
        for (i in 0 until steps.length()) {
            val s = steps.getJSONObject(i)
            val act = s.optString("action"); val arg = s.optString("arg")
            val ok = when (act) {
                "open_app" -> { val o = Actions.openApp(this, arg); if (o) waitOpen(Actions.lastPkg); o }
                "tap" -> tapText(arg)
                "type" -> typeText(arg)
                "submit" -> submit()
                "scroll_down" -> scroll("down")
                "scroll_up" -> scroll("up")
                "play_youtube" -> playOnYoutube(arg).startsWith("done")
                "wait" -> { nap((arg.toLongOrNull() ?: 500L).coerceIn(50L, 3000L)); true }
                "home", "back", "recents", "notifications", "quick_settings", "lock", "screenshot" -> global(act)
                else -> false
            }
            if (!ok) return "failed at step ${i + 1} ($act $arg). Screen: " + readScreen(900)
            if (act == "home" || act == "back" || act == "recents" || act == "notifications" || act == "quick_settings") nap(250)
        }
        return "all steps done"
    }
}

object Actions {
    @Volatile var lastPkg: String = ""
    fun openApp(ctx: Context, name: String): Boolean {
        val pm = ctx.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = list.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
            ?: list.firstOrNull { it.loadLabel(pm).toString().contains(name, true) } ?: return false
        val l = pm.getLaunchIntentForPackage(m.activityInfo.packageName) ?: return false
        l.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        lastPkg = m.activityInfo.packageName
        (DivyaService.instance ?: ctx).startActivity(l)
        return true
    }
}
