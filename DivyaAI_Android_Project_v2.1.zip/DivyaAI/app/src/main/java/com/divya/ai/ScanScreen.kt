package com.divya.ai

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.net.Uri
import android.util.Size
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

fun camOk(c: Context) = c.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

/** Scanner ke Divya-wale modes: label -> sawal jo Divya ko jaata hai. */
private val scanModes = listOf(
    "Ye kya hai?" to "Camera mein jo dikh raha hai use dekho aur batao ye kya hai.",
    "Text padho" to "Camera mein jo text ya document dikh raha hai use poora padhkar sunao.",
    "Translate" to "Camera mein jo text dikh raha hai use padho aur asaan Hindi (agar Hindi hai to English) mein translate karke batao.",
    "Sawal solve" to "Camera mein jo sawal ya math/homework dikh raha hai use step by step solve karo, aakhir mein final answer saaf batao.",
    "Khana" to "Ye khana dekho, batao kya hai aur andaza lagao ki approx calories aur protein kitna hoga. Saaf bolo ki ye sirf andaza hai.",
    "Product" to "Ye product pehchano: kya hai, kis kaam aata hai, aur kharidne se pehle kya dhyan rakhna chahiye.",
    "Document" to "Ye document dekho aur uska chhota summary do, zaroori tarikh, naam aur amount alag se batao.",
    "Samjhao" to "Jo dikh raha hai use asaan Hinglish mein samjhao."
)

/**
 * Scanner / "Dekho": live camera + Divya ko 1 frame/sec.
 * Naya: Text copy (OCR Hindi+English, phone par), torch, front/back camera, zoom, zyada modes.
 */
@Composable
fun ScanScreen(th: UiTheme, live: GeminiLive, running: Boolean, status: String, startSession: () -> Unit, ask: (String) -> Unit, close: () -> Unit) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(camOk(ctx)) }
    var qr by remember { mutableStateOf<String?>(null) }
    var ocr by remember { mutableStateOf<String?>(null) }
    var busyOcr by remember { mutableStateOf(false) }
    var torch by remember { mutableStateOf(false) }
    var front by remember { mutableStateOf(false) }
    var zoom by remember { mutableStateOf(0f) }
    val lastFrame = remember { arrayOfNulls<Bitmap>(1) }
    val camRef = remember { arrayOfNulls<Camera>(1) }
    val recognizer = remember { TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()) }
    DisposableEffect(Unit) { onDispose { try { recognizer.close() } catch (_: Exception) {} } }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }
    // Screen khulte hi Divya ka session shuru karo (agar chal nahi raha)
    LaunchedEffect(granted) { if (granted && !live.running) startSession() }
    LaunchedEffect(torch) { try { camRef[0]?.cameraControl?.enableTorch(torch) } catch (_: Exception) {} }
    LaunchedEffect(zoom) { try { camRef[0]?.cameraControl?.setLinearZoom(zoom) } catch (_: Exception) {} }

    fun copy(t: String) {
        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Divya scan", t))
        Toast.makeText(ctx, "Copy ho gaya", Toast.LENGTH_SHORT).show()
    }
    fun share(t: String) {
        try {
            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), null)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }
    fun runOcr() {
        val b = lastFrame[0]
        if (b == null) { ocr = "Abhi frame nahi mila, camera ko 1 second steady rakho."; return }
        busyOcr = true
        recognizer.process(InputImage.fromBitmap(b, 0))
            .addOnSuccessListener { r -> busyOcr = false; ocr = r.text.trim().ifBlank { "Koi text nahi mila. Paas jao ya roshni badhao." } }
            .addOnFailureListener { e -> busyOcr = false; ocr = "Text nikalne mein dikkat: ${e.message}" }
    }

    Box(Modifier.fillMaxSize()) {
        if (granted) {
            key(front) {
                CameraPreview(live, front, { torch }, { zoom }, camRef, { lastFrame[0] = it }) { v -> if (v != qr) qr = v }
            }
        } else {
            Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Text("Divya ko dekhne ke liye Camera permission chahiye", color = th.text, textAlign = TextAlign.Center, fontSize = 16.sp)
                Spacer(Modifier.height(12.dp))
                Btn(th, "Camera Allow karo") { launcher.launch(Manifest.permission.CAMERA) }
            }
        }
        // Upar: status + torch / flip / close
        Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(16.dp))
            .background(Color.Black.copy(alpha = 0.55f)).padding(start = 12.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.QrCodeScanner, "Scanner", tint = th.accent)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text("Divya Scanner", color = Color.White, fontWeight = FontWeight.Bold)
                Text(if (running) "👁️ Divya dekh rahi hai • $status" else "Connect ho raha hai… ($status)", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp, maxLines = 1)
            }
            IconButton({ torch = !torch }) { Icon(if (torch) Icons.Filled.FlashOn else Icons.Filled.FlashOff, "Torch", tint = if (torch) th.accent else Color.White) }
            IconButton({ front = !front; torch = false; zoom = 0f }) { Icon(Icons.Filled.FlipCameraAndroid, "Camera badlo", tint = Color.White) }
            IconButton(close) { Icon(Icons.Filled.Close, "Band karo", tint = Color.White) }
        }
        // Neeche: results, zoom, modes
        if (granted) Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ocr?.let { t ->
                ResultCard(th, "📋 Text (phone par nikala)", t, listOf(
                    "Copy" to { copy(t) }, "Share" to { share(t) },
                    "Divya ko batao" to { ask("Camera se ye text nikla: " + t.take(1500) + " . Iska matlab/summary batao.") },
                    "Band" to { ocr = null }))
            }
            qr?.let { v ->
                ResultCard(th, "✅ QR / Code mila", v, listOfNotNull(
                    if (v.startsWith("http", true)) "Kholo" to {
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(v)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                    } else null,
                    "Copy" to { copy(v) },
                    "Divya ko batao" to { ask("Camera ne ye QR/barcode padha: " + v.take(500) + " . Iska matlab batao aur ye safe lagta hai ya nahi?") },
                    "Band" to { qr = null }))
            }
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.Black.copy(alpha = 0.5f)).padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.ZoomIn, "Zoom", tint = Color.White, modifier = Modifier.size(18.dp))
                Slider(zoom, { zoom = it }, Modifier.weight(1f).height(28.dp))
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScanChip(th, if (busyOcr) "⏳ Text…" else "📋 Text copy", Modifier) { if (!busyOcr) runOcr() }
                scanModes.forEach { (l, q) -> ScanChip(th, l, Modifier) { ask(q) } }
            }
            Text("Bolo bhi sakte ho: “ye kya hai?”, “ye padh do”, “ye solve karo”", color = Color.White, fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(alpha = 0.45f)).padding(6.dp))
        }
    }
}

@Composable
private fun ResultCard(th: UiTheme, title: String, text: String, actions: List<Pair<String, () -> Unit>>) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.Black.copy(alpha = 0.78f))
        .border(1.dp, th.accent, RoundedCornerShape(16.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, color = th.accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(text.take(2000), color = Color.White, fontSize = 13.sp, modifier = Modifier.heightIn(max = 150.dp).verticalScroll(rememberScrollState()))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            actions.forEach { (l, f) -> ScanChip(th, l, Modifier, f) }
        }
    }
}

@Composable
private fun ScanChip(th: UiTheme, label: String, modifier: Modifier, onClick: () -> Unit) {
    Button(onClick, modifier.border(1.dp, th.accent, RoundedCornerShape(22.dp)), shape = RoundedCornerShape(22.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Black.copy(alpha = 0.6f))) { Text(label, color = Color.White, fontSize = 13.sp, maxLines = 1) }
}

@Composable
private fun CameraPreview(
    live: GeminiLive, front: Boolean, torchNow: () -> Boolean, zoomNow: () -> Float,
    camRef: Array<Camera?>, onFrame: (Bitmap) -> Unit, onQr: (String) -> Unit
) {
    val owner = LocalLifecycleOwner.current
    val exec = remember { Executors.newSingleThreadExecutor() }
    val providerRef = remember { arrayOfNulls<ProcessCameraProvider>(1) }
    val scanner = remember { BarcodeScanning.getClient() }
    DisposableEffect(Unit) {
        onDispose {
            try { providerRef[0]?.unbindAll() } catch (_: Exception) {}
            camRef[0] = null
            exec.shutdown(); try { scanner.close() } catch (_: Exception) {}
        }
    }
    AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
        val pv = PreviewView(c).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        val fut = ProcessCameraProvider.getInstance(c)
        fut.addListener({
            try {
                val provider = fut.get(); providerRef[0] = provider
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                var lastScan = 0L
                var lastSend = 0L
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(720, 1280))   // OCR ke liye saaf frame
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(exec) { img ->
                    try {
                        val now = System.currentTimeMillis()
                        if (now - lastScan >= 600) {
                            lastScan = now
                            var bmp: Bitmap = img.toBitmap()
                            val rot = img.imageInfo.rotationDegrees
                            if (rot != 0) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
                            onFrame(bmp)   // full-size frame (Text copy / OCR ke liye)
                            val sc = 768f / maxOf(bmp.width, bmp.height)
                            val small = if (sc < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true) else bmp
                            // QR / barcode decode (phone par hi, internet nahi chahiye)
                            scanner.process(InputImage.fromBitmap(small, 0)).addOnSuccessListener { codes ->
                                val v = codes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
                                if (v != null) onQr(v)
                            }
                            // Divya ko live frame (1 per second)
                            if (live.running && now - lastSend >= 1000) {
                                lastSend = now
                                val out = ByteArrayOutputStream()
                                small.compress(Bitmap.CompressFormat.JPEG, 70, out)
                                live.sendFrame(out.toByteArray())
                            }
                        }
                    } catch (_: Exception) {
                    } finally { img.close() }
                }
                provider.unbindAll()
                val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                val cam = provider.bindToLifecycle(owner, sel, preview, analysis)
                camRef[0] = cam
                try { cam.cameraControl.setLinearZoom(zoomNow()) } catch (_: Exception) {}
                if (!front) try { cam.cameraControl.enableTorch(torchNow()) } catch (_: Exception) {}
            } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(c))
        pv
    })
}
